"""Bounded real-socket unsubscribe barrier and resubscribe correctness check."""
import argparse,hashlib,importlib.util,json,os,subprocess,tempfile,time,traceback
from pathlib import Path
ROOT=Path('/home/phil/.codex/worktrees/departure-quantum/war_next')
spec=importlib.util.spec_from_file_location('departure',ROOT/'scripts/departure-fairness.py')
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
wire=fixture.wire
parser=argparse.ArgumentParser();parser.add_argument('--server',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--audience',type=int,default=100000);args=parser.parse_args()
port,admin=wire.runtime.free_port(),wire.runtime.free_port()
command=['taskset','-c','0-7',str(args.server.resolve()),'--bind',f'127.0.0.1:{port}','--admin-bind',f'127.0.0.1:{admin}','--workers','8','--pin-workers','--max-connections',str(args.audience+2),'--max-channel-members',str(args.audience+1),'--ping-interval-secs','0','--idle-timeout-secs','0','--messages-per-second','0','--bytes-per-second','0','--shutdown-timeout-secs','2','--tcp-send-buffer-bytes','16384','--tcp-receive-buffer-bytes','65536']
env={k:v for k,v in os.environ.items() if not k.startswith('WAR_')};env['WAR_AUTH_PASSWORD']='observer-barrier'
result={'passed':False,'command':command,'server_sha256':hashlib.sha256(args.server.read_bytes()).hexdigest(),'fixture_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'audience':args.audience,'sequence':[],'server_forced_kill':False}
peers=[]
def join(name):
 p=fixture.Peer(port,name,len(peers));peers.append(p);return p

def request(peer,body,expected):
 peer.socket.sendall(wire.frame(0x82,body));assert peer.receive()==(2,expected)

def notice(body,source):
 assert body[0]==0x82
 sender,offset=wire.uint(body,1);value,end=wire.uint(body,offset)
 assert sender==2**64-1 and value==source and end==len(body)

with args.output.open('x') as output,tempfile.TemporaryFile() as log:
 server=subprocess.Popen(command,env=env,stdout=log,stderr=log)
 try:
  for _ in range(200):
   if server.poll() is not None:raise RuntimeError('server startup failed')
   try:wire.runtime.metrics(admin);break
   except OSError:time.sleep(.02)
  else:raise TimeoutError('server startup')
  began=time.monotonic();source=join(b'revocation')
  audience=[]
  for _ in range(args.audience):
   if time.monotonic()-began>60:raise TimeoutError('setup budget')
   audience.append(join(b'revocation'))
  observer=join(b're_globl')
  request(observer,b'\x82\x00\x82\x00\x70observer-barrier',b'\x82\x00\x82\x00\xf5')
  request(observer,b'\x82\x00\x82\x01\x01',b'\x82\x00\x82\x01\x01')
  source.close()
  began=time.monotonic_ns()
  observer.socket.sendall(wire.frame(0x82,b'\x82\x00\x82\x01\x00'))
  notices=0
  for _ in range(2):
   opcode,body=observer.receive();assert opcode==2
   if body==b'\x82\x00\x82\x01\x00':
    result['sequence'].append('unsubscribe_ack');break
   notice(body,source.id);notices+=1;result['sequence'].append('departure')
  else:raise AssertionError('missing unsubscribe acknowledgment')
  result['unsubscribe_ack_ms']=(time.monotonic_ns()-began)/1e6
  for peer in audience:peer.departure(source.id)
  observer.socket.settimeout(.1)
  try:
   opcode,body=observer.receive();assert opcode==2;notice(body,source.id)
   notices+=1;result['sequence'].append('late_departure')
  except TimeoutError:pass
  observer.socket.settimeout(5)
  assert notices==1,'original notice missing or duplicated'
  # Re-enable and prove the observer still receives a new epoch's departure.
  request(observer,b'\x82\x00\x82\x01\x01',b'\x82\x00\x82\x01\x01')
  fresh=join(b'revocation');fresh.close()
  observer.departure(fresh.id)
  for peer in audience:peer.departure(fresh.id)
  result['resubscribe_verified']=True
  observer.close()
  for _ in range(100):
   metrics=wire.runtime.metrics(admin)
   if int(metrics['war_sessions'])==args.audience and int(metrics['war_queued_bytes'])==0:break
   time.sleep(.01)
  result['after']=metrics
  assert int(metrics['war_sessions'])==args.audience and int(metrics['war_queued_bytes'])==0
  assert int(metrics['war_routing_copied_bytes_total'])==0
  for key in wire.ZERO_ERRORS:assert int(metrics[key])==0,(key,metrics[key])
  result['passed']=result['sequence']==['departure','unsubscribe_ack']
 except Exception:result['error']=traceback.format_exc()
 finally:
  if server.poll() is None:
   server.terminate()
   if peers:
    try:
     opcode,body=peers[1].receive();assert opcode==8 and int.from_bytes(body[:2],'big')==1001
     result['shutdown_close_verified']=True
    except Exception:pass
   for peer in peers:peer.socket.close()
   try:server.wait(timeout=6)
   except subprocess.TimeoutExpired:result['server_forced_kill']=True;server.kill();server.wait(timeout=3)
  result['server_exit']=server.returncode
  if server.returncode!=0 or result['server_forced_kill']:result['passed']=False
  log.seek(0);result['server_log']=log.read().decode(errors='replace')
 json.dump(result,output,indent=2);output.write('\n')
print(json.dumps({k:result.get(k) for k in ['passed','sequence','unsubscribe_ack_ms','resubscribe_verified','error']}))
raise SystemExit(0 if result['passed'] else 1)
