import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import test from 'node:test';
const source = await readFile(new URL('../target/browser/relay.js', import.meta.url));
const moduleUrl = `data:text/javascript;base64,${source.toString('base64')}`;
const nodeBuffer = globalThis.Buffer;
globalThis.Buffer = undefined;
let Relay;
try { ({ Relay } = await import(moduleUrl)); }
finally { globalThis.Buffer = nodeBuffer; }

test('built module captures a queued variable before mutation and transfer', async t => {
  const relay = await Relay.connect(process.env.WAR_TEST_URL, 'js-bundle-cmd');
  t.after(() => relay.close());
  const prior = relay.getVariable('absent');
  const value = { bytes: new Uint8Array([3, 4]), label: 'before' };
  const pending = relay.setVariable('snapshot', value);
  value.label = 'after';
  structuredClone(value.bytes.buffer, { transfer: [value.bytes.buffer] });
  await prior;
  assert.equal(await pending, true);
  assert.deepEqual(await relay.getVariable('snapshot'), {
    found: true, value: { bytes: new Uint8Array([3, 4]), label: 'before' },
  });
});
