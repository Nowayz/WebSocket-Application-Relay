import subprocess
from pathlib import Path
for index,kind in enumerate(['control','candidate','candidate','control']):
 server='idle-snapshot' if kind=='control' else 'header-on-demand'
 command=['python','scripts/inspection.py','--server',f'artifacts/candidates/{server}/war-relay','--client','artifacts/candidates/value-kind/inspection','--client-source-root','artifacts/value-kind-work','--mode','none','--rooms','0','--seconds','2','--inspectors','0','--pairs','0','--churn-workers','0','--client-workers','8','--workers','4','--fanout-readers','2048','--fanout-window','4','--fanout-close-window','32','--pin-workers','--pin-client-workers','--server-cpus','0-3','--client-cpus','4-7,20-23','--output',f'artifacts/header-on-demand-{index}-{kind}.json']
 with open(f'artifacts/header-on-demand-{index}-{kind}.log','w') as log:
  subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=60)
 print(index,kind,flush=True)
