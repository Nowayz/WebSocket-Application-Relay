import subprocess
for index,variant in enumerate(['baseline','current','current','baseline']):
 server='mixed-capacity-final' if variant=='baseline' else 'queue-initial-control'
 command=['python','scripts/mixed-capacity.py','--server',f'artifacts/candidates/{server}/war-relay','--sidecar','artifacts/candidates/value-kind/inspection','--capacity-client','artifacts/candidates/latency-timeline-client/capacity','--users','100000','--seconds','2','--readers','8192','--scope','room','--window','4','--inspectors','0','--pairs','0','--churn-cycles-per-second','0','--fanout-windows-per-second','16','--exact-fanout-latency','--pin-client-workers','--output',f'artifacts/short-current-100k-{index}-{variant}.json']
 print('starting',index,variant,flush=True)
 with open(f'artifacts/short-current-100k-{index}-{variant}.log','w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
 print('finished',index,variant,flush=True)
