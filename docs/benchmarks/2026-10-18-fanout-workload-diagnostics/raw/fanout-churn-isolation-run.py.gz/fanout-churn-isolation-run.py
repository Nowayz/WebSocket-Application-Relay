import subprocess
for index,workers in enumerate([8,0,0,8]):
 command=['python','scripts/mixed-capacity.py','--server','artifacts/candidates/queue-initial-control/war-relay','--sidecar','artifacts/candidates/value-kind/inspection','--capacity-client','artifacts/candidates/latency-timeline-client/capacity','--users','100000','--seconds','2','--readers','8192','--scope','room','--window','4','--inspectors','0','--pairs','0','--churn-workers',str(workers),'--churn-cycles-per-second','0','--fanout-windows-per-second','16','--exact-fanout-latency','--pin-client-workers','--output',f'artifacts/fanout-churn-isolation-{index}-w{workers}.json']
 print('starting',index,workers,flush=True)
 with open(f'artifacts/fanout-churn-isolation-{index}-w{workers}.log','w') as log:
  result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  assert result.returncode in [0,1]
 print('finished',index,workers,'status',result.returncode,flush=True)
