import os,subprocess
from pathlib import Path
env=os.environ.copy();env['PYTHONPATH']=str(Path('scripts').resolve())+(os.pathsep+env['PYTHONPATH'] if env.get('PYTHONPATH') else '')
for index,mode in enumerate(['light','heavy','heavy','light']):
 runner='scripts/mixed-capacity.py' if mode=='light' else 'artifacts/mixed-capacity-with-fd-scans.py'
 command=['python',runner,'--server','artifacts/candidates/queue-initial-control/war-relay','--sidecar','artifacts/candidates/value-kind/inspection','--capacity-client','artifacts/candidates/latency-timeline-client/capacity','--users','100000','--seconds','2','--readers','8192','--scope','room','--window','4','--inspectors','0','--pairs','0','--churn-workers','0','--churn-cycles-per-second','0','--fanout-windows-per-second','16','--exact-fanout-latency','--pin-client-workers','--output',f'artifacts/fanout-monitor-isolation-{index}-{mode}.json']
 print('starting',index,mode,flush=True)
 with open(f'artifacts/fanout-monitor-isolation-{index}-{mode}.log','w') as log:
  result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  assert result.returncode in [0,1]
 print('finished',index,mode,'status',result.returncode,flush=True)
