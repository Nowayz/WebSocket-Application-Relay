import importlib.util,json,subprocess,sys,time
from pathlib import Path
sys.path.insert(0,str(Path('scripts').resolve()))
spec=importlib.util.spec_from_file_location('mixed',Path('scripts/mixed-capacity.py'));mixed=importlib.util.module_from_spec(spec);spec.loader.exec_module(mixed)
program="import os,resource,sys\nsoft,hard=resource.getrlimit(resource.RLIMIT_NOFILE)\nresource.setrlimit(resource.RLIMIT_NOFILE,(max(soft,100016),hard))\nfds=[os.open('/dev/null',os.O_RDONLY) for _ in range(100000)]\nprint(os.getpid(),flush=True)\nsys.stdin.readline()\n"
p=subprocess.Popen([sys.executable,'-c',program],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
rows=[]
try:
 pid=int(p.stdout.readline())
 for enabled in [True,False,False,True,False,True]:
  began=time.perf_counter();cpu=time.process_time();result=mixed.snapshot(pid,include_fds=enabled)
  rows.append({'include_fds':enabled,'wall_ms':(time.perf_counter()-began)*1000,'cpu_ms':(time.process_time()-cpu)*1000,'fds':result['fds']})
finally:
 if p.poll() is None:p.stdin.write('stop\n');p.stdin.flush()
 p.wait(timeout=10)
record={'rows':rows,'child_exit':p.returncode,'scope':'100000 held /dev/null descriptors; controller-only snapshot cost, not a relay benchmark'}
Path('artifacts/fd-snapshot-cost.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
