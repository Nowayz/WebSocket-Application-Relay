import subprocess
for index, variant in enumerate(['control','candidate','candidate','control']):
    command=['python','scripts/stability.py','--server',f'artifacts/candidates/shared-rate-{variant}/war-relay',
             '--stress','artifacts/candidates/mixed-capacity-pressure-client/stress','--modes','traffic',
             '--traffic-secs','2','--clients','64','--workers','4','--server-cpus','0-3','--client-cpus','8-11',
             '--output',f'artifacts/shared-rate-small-{index}-{variant}.json']
    print('starting',index,variant,flush=True)
    with open(f'artifacts/shared-rate-small-{index}-{variant}.log','x') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=45)
    assert result.returncode==0,(index,result.returncode)
    print('finished',index,variant,flush=True)
