import subprocess
for workload in ['churn-mixed','private']:
 for index,kind in enumerate(['control','candidate','candidate','control']):
  server='single-slice-control' if kind=='control' else 'single-slice'
  command=['python','scripts/inspection.py','--server',f'artifacts/candidates/{server}/war-relay','--client','artifacts/candidates/value-kind/inspection','--client-source-root','artifacts/value-kind-work','--mode','none','--rooms','0','--seconds','2','--inspectors','0','--pairs','1' if workload=='churn-mixed' else '64','--churn-workers','8' if workload=='churn-mixed' else '0','--client-workers','8','--workers','4','--pin-workers','--pin-client-workers','--server-cpus','0-3','--client-cpus','4-7,20-23','--output',f'artifacts/single-slice-{workload}-{index}-{kind}.json']
  with open(f'artifacts/single-slice-{workload}-{index}-{kind}.log','w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=60)
  print(workload,index,kind,flush=True)
