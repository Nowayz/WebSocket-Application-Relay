
artifacts/candidates/queue-initial-control/war-relay:     file format elf64-x86-64


Disassembly of section .text:

00000000002a2060 <war_relay::protocol::validate_value>:
  2a2060:	55                   	push   %rbp
  2a2061:	41 57                	push   %r15
  2a2063:	41 56                	push   %r14
  2a2065:	41 55                	push   %r13
  2a2067:	41 54                	push   %r12
  2a2069:	53                   	push   %rbx
  2a206a:	48 81 ec 28 03 00 00 	sub    $0x328,%rsp
  2a2071:	49 89 f6             	mov    %rsi,%r14
  2a2074:	48 89 3c 24          	mov    %rdi,(%rsp)
  2a2078:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
  2a207f:	00 
  2a2080:	31 db                	xor    %ebx,%ebx
  2a2082:	ba 00 02 00 00       	mov    $0x200,%edx
  2a2087:	31 f6                	xor    %esi,%esi
  2a2089:	ff 15 59 21 06 00    	call   *0x62159(%rip)        # 3041e8 <memset@GLIBC_2.2.5>
  2a208f:	48 c7 84 24 20 01 00 	movq   $0x1,0x120(%rsp)
  2a2096:	00 01 00 00 00 
  2a209b:	41 bf 01 00 00 00    	mov    $0x1,%r15d
  2a20a1:	31 ed                	xor    %ebp,%ebp
  2a20a3:	49 89 dd             	mov    %rbx,%r13
