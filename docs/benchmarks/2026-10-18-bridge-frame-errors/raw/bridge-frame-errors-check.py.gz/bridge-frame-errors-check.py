import argparse,hashlib,importlib.util,json,os,socket,subprocess,time,urllib.request
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--bridge',required=True);parser.add_argument('--output',required=True);args=parser.parse_args()
root=Path.cwd();output=Path(args.output)
spec=importlib.util.spec_from_file_location('corpus',root/'scripts/input-corpus.py');corpus=importlib.util.module_from_spec(spec);spec.loader.exec_module(corpus)
def port():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
ports=set()
while len(ports)<3:ports.add(port())
native,admin,legacy=ports
server=root/'artifacts/candidates/idle-snapshot/war-relay';bridge=Path(args.bridge).resolve()
env={k:v for k,v in os.environ.items() if not k.startswith('WAR_')};env['WAR_ADMIN_TOKEN']='oversize-check'
commands=[[str(server),'--bind',f'127.0.0.1:{native}','--admin-bind',f'127.0.0.1:{admin}','--workers','4','--ping-interval-secs','0'],[str(bridge),'--bind',f'127.0.0.1:{legacy}','--upstream',f'ws://127.0.0.1:{native}']]
record={'passed':False,'commands':commands,'bridge_sha256':hashlib.sha256(bridge.read_bytes()).hexdigest(),'cases':[]};processes=[];logs=[];peers=[]
try:
 for index,cmd in enumerate(commands):
  log=output.with_suffix(f'.{index}.log').open('w');logs.append(log);processes.append(subprocess.Popen(cmd,env=env,stdout=log,stderr=log))
 for _ in range(300):
  try:
   with urllib.request.urlopen(f'http://127.0.0.1:{admin}/readyz',timeout=.2):pass
   with socket.create_connection(('127.0.0.1',legacy),timeout=.2):pass
   break
  except OSError:time.sleep(.01)
 witness=corpus.Peer(native);peers.append(witness);witness.join(b'oversize-proof')
 frames=[('oversize',b'\x82\xff'+(16*1024*1024+1).to_bytes(8,'big')+bytes(4),1009),('unmasked',b'\x82\x01*',1002),('reserved-opcode',b'\x83\x80'+bytes(4),1002),('fragmented-ping',b'\x09\x80'+bytes(4),1002),('invalid-utf8',b'\x81\x81'+bytes(4)+b'\xff',1007)]
 for joined,kind,header,expected in [(joined,*frame) for joined in [False,True] for frame in frames]:
  peer=corpus.Peer(legacy);peers.append(peer)
  if joined:
   peer.socket.sendall(corpus.wire.frame(0x82,b'oversize-old'));assert peer.receive()[0]==2
  peer.socket.sendall(header)
  result={'joined':joined,'kind':kind,'header_bytes':len(header),'expected':expected}
  try:
   opcode,body=peer.receive();result.update(opcode=opcode,code=int.from_bytes(body[:2],'big'),reason=body[2:].decode());result['passed']=opcode==8 and result['code']==expected
  except (EOFError,OSError) as error:result.update(passed=False,error=type(error).__name__)
  peer.socket.close()
  witness.socket.sendall(corpus.wire.frame(0x82,(b'\x82\x1b'+witness.id.to_bytes(8,'big')+b'\x18\x2a')))
  assert witness.receive()==(2,(b'\x82\x1b'+witness.id.to_bytes(8,'big')+b'\x18\x2a'))
  result['healthy_native_fifo']=True;record['cases'].append(result)
 witness.socket.close()
 for _ in range(300):
  req=urllib.request.Request(f'http://127.0.0.1:{admin}/metrics',headers={'Authorization':'Bearer oversize-check'})
  with urllib.request.urlopen(req,timeout=2) as r:metrics=dict((k,int(v)) for k,v in (line.split() for line in r.read().decode().splitlines() if line.startswith('war_')))
  if metrics['war_connections']==metrics['war_sessions']==metrics['war_queued_bytes']==0:break
  time.sleep(.01)
 record['final_gauges']={k:metrics[k] for k in ['war_connections','war_sessions','war_queued_bytes','war_variable_bytes']};assert not any(record['final_gauges'].values())
 record['passed']=all(x['passed'] for x in record['cases'])
finally:
 for p in peers:p.socket.close()
 for p in reversed(processes):
  if p.poll() is None:p.terminate()
  p.wait(timeout=10)
 record['exit_codes']=[p.returncode for p in processes]
 for log in logs:log.close()
 output.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record));raise SystemExit(0 if record['passed'] else 1)
