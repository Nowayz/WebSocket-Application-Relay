import hashlib,json,os,socket,subprocess
from pathlib import Path
root=Path.cwd();cases=[];env={k:v for k,v in os.environ.items() if not k.startswith('WAR_')}
with socket.socket() as occupied:
 occupied.bind(('127.0.0.1',0));occupied.listen()
 bind='127.0.0.1:'+str(occupied.getsockname()[1])
 for variant,name in [('control','simd-text'),('selected','bridge-upstream')]:
  binary=root/f'artifacts/candidates/{name}/war-legacy-bridge'
  for upstream in ['not a URL','http://localhost/','ws://','/relative','ws://127.0.0.1:1338']:
   command=[str(binary),'--bind',bind,'--upstream',upstream]
   result=subprocess.run(command,env=env,capture_output=True,text=True,timeout=5)
   expected='invalid legacy upstream URL' if variant=='selected' and upstream!='ws://127.0.0.1:1338' else 'cannot bind legacy bridge'
   assert result.returncode!=0 and expected in result.stderr,(command,result)
   cases.append({'variant':variant,'command':command,'server_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'expected_error':expected})
(root/'artifacts/bridge-upstream-cli.json').write_text(json.dumps({'passed':True,'cases':cases},indent=2)+'\n')
print('Ten startup-order cases passed against an occupied frontend address.')
