import assert from 'node:assert/strict';
import { once } from 'node:events';
import { readFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import test from 'node:test';
const codec = pathToFileURL(`${process.cwd()}/clients/js/node_modules/cbor-x/node-index.js`).href;
const source = (await readFile('artifacts/js-serialization-reentry-original.mjs', 'utf8'))
  .replace("from 'cbor-x'", `from '${codec}'`);
const { Relay } = await import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);

test('original client emits the nested message then receives native protocol Close 1002', async t => {
  const relay = await Relay.connect(process.env.WAR_TEST_URL, 'js-old-wire');
  t.after(() => relay.close());
  const message = once(relay, 'message');
  const closed = once(relay, 'close');
  assert.doesNotThrow(() => relay.send(relay.userId, { get child() {
    relay.send(relay.userId, 'nested');
    return 'outer';
  } }));
  assert.deepEqual((await message)[0].detail, { sender: relay.userId, value: 'nested' });
  assert.equal((await closed)[0].detail.code, 1002);
});
