import { readFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
const sourceFile = process.argv[2];
const codec = pathToFileURL(`${process.cwd()}/clients/js/node_modules/cbor-x/node-index.js`).href;
const original = await readFile(sourceFile, 'utf8');
const sourceHash = createHash('sha256').update(original).digest('hex');
const source = original.replace("from 'cbor-x'", `from '${codec}'`);
const { Relay } = await import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);
class Socket extends EventTarget {
  readyState = 1;
  bytes = 0;
  send(bytes) { this.bytes += bytes.byteLength; }
  close() { this.readyState = 3; }
}
const socket = new Socket();
const relay = new Relay(socket, 1n);
const payload = new Uint8Array(1024);
for (let i = 0; i < 20000; i++) relay.send(2n, payload);
const ns = [];
for (let repeat = 0; repeat < 3; repeat++) {
  const start = process.hrtime.bigint();
  for (let i = 0; i < 100000; i++) relay.send(2n, payload);
  ns.push(Number(process.hrtime.bigint() - start) / 100000);
}
relay.close();
console.log(JSON.stringify({ sourceFile, sourceHash, node: process.version, payloadBytes: payload.length, warmup: 20000,
  iterations: 100000, nsPerSend: ns, encodedBytes: socket.bytes,
  scope: 'Synchronous JS serialization and sink call only; no WebSocket transport or relay latency' }));
