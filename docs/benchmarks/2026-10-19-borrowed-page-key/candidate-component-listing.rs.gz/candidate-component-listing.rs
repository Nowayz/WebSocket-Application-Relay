use base64::{Engine, engine::general_purpose::STANDARD};
use std::num::NonZeroUsize;

use super::{ChannelSnapshot, MAX_CHANNEL_PAGE_SIZE, Relay, SnapshotName};

impl Relay {
    /// Select bounded batches from one coherent registry view. Each partition
    /// discards rows that cannot enter the smallest page. Scratch space holds
    /// at most two pages of keys and owned metadata, never peer/value bodies.
    pub(crate) fn channel_page(
        &self,
        limit: NonZeroUsize,
        after: Option<[u8; 24]>,
    ) -> Vec<ChannelSnapshot> {
        let limit = limit.get().min(MAX_CHANNEL_PAGE_SIZE);
        let state = self.state.read();
        let capacity = (2 * limit).min(state.channels.len());
        let mut selected = Vec::new();
        for (name, channel) in &state.channels {
            let mut key = [0; 24];
            STANDARD
                .encode_slice(name, &mut key)
                .expect("16-byte channel names fit in 24 base64 bytes");
            if after.is_some_and(|after| key <= after) {
                continue;
            }
            if selected.is_empty() {
                selected.reserve_exact(capacity);
            }
            selected.push((
                key,
                ChannelSnapshot {
                    name: SnapshotName::new(name),
                    members: channel.members.len(),
                    variables: channel.variables.len(),
                    variable_bytes: channel.variable_bytes,
                },
            ));
            // Keep one page of candidates and make room for the next batch.
            if selected.len() == 2 * limit {
                selected.select_nth_unstable_by_key(limit, |row| row.0);
                selected.truncate(limit);
            }
        }
        drop(state);
        // Ordering and output conversion need no registry guard.
        selected.sort_unstable_by_key(|row| row.0);
        selected.truncate(limit);
        selected.into_iter().map(|(_, snapshot)| snapshot).collect()
    }
}


#[cfg(test)]
mod allocation_screen {
    use super::*;
    use std::{hint::black_box, io::{self, Write}, time::Instant};
    fn gate(marker: &str) {
        println!("{marker}");
        io::stdout().flush().unwrap();
        if std::env::var_os("PAGE_HEAP_GATES").is_some() {
            let mut line=String::new();io::stdin().read_line(&mut line).unwrap();assert_eq!(line,"go\n");
        }
    }
    #[test]
    #[ignore]
    fn management_page_screen() {
        let relay=Relay::new(crate::Config::default()).unwrap();
        let mut members=Vec::new();
        for i in 0..8192 {
            let mut sub=relay.subscribe(format!("m{i:08}").as_bytes()).unwrap();
            sub.outgoing.try_recv().unwrap();members.push(sub);
        }
        let all=relay.channel_listing();assert_eq!(all.len(),8193);
        let limit=NonZeroUsize::new(1000).unwrap();
        let tail=all[all.len()-17].name.base64();
        let empty=SnapshotName::new(&[0xcc;16]).base64();
        assert_eq!(serde_json::to_vec(&relay.channel_page(limit,None)).unwrap(),serde_json::to_vec(&all[..1000]).unwrap());
        assert_eq!(serde_json::to_vec(&relay.channel_page(limit,Some(tail))).unwrap(),serde_json::to_vec(&all[all.len()-16..]).unwrap());
        assert!(relay.channel_page(limit,Some(empty)).is_empty());
        gate("PAGE_READY");
        for (name,after,expected) in [("first",None,1000),("tail",Some(tail),16),("empty",Some(empty),0)] {
            for _ in 0..10 {black_box(relay.channel_page(limit,black_box(after)));}
            let mut times=Vec::new();
            for _ in 0..9 {
                let start=Instant::now();
                for _ in 0..100 {let page=relay.channel_page(limit,black_box(after));assert_eq!(page.len(),expected);black_box(page);}
                times.push(start.elapsed().as_nanos() as f64/100.0);
            }
            println!("{{\"case\":\"{name}\",\"operations_per_batch\":100,\"ns_per_operation\":{times:?}}}");
        }
        gate("PAGE_DONE");
        drop(members);assert_eq!(relay.counts(),(0,1));
    }
}
