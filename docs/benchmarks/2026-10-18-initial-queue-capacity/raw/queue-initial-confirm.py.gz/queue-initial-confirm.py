import subprocess
for window in [1]:
 for index,kind in enumerate(['candidate','control','control','candidate']):
  command=['python','scripts/inspection.py','--server',f"artifacts/candidates/queue-initial-{'selected' if kind == 'candidate' else 'control'}/war-relay",'--client','artifacts/candidates/value-kind/inspection','--client-source-root','artifacts/value-kind-work','--mode','none','--rooms','0','--seconds','2','--inspectors','0','--pairs','64','--churn-workers','0','--client-workers','8','--workers','4','--fanout-readers','2048','--fanout-window',str(window),'--fanout-close-window','32','--pin-workers','--pin-client-workers','--server-cpus','0-3','--client-cpus','4-7,20-23','--output',f'artifacts/queue-initial-confirm-w{window}-{index}-{kind}.json']
  with open(f'artifacts/queue-initial-confirm-w{window}-{index}-{kind}.log','w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=60)
  print(window,index,kind,flush=True)
