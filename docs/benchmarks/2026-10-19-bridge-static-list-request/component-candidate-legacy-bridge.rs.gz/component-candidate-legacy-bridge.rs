//! Optional migration adapter. The relay runtime itself only speaks CBOR.
use crate::{
    legacy,
    protocol::{self, BROADCAST, Disconnect},
    transport,
};
use anyhow::{Context, Result, bail};
use base64::{Engine, engine::general_purpose::STANDARD};
use bytes::Bytes;
use futures_util::{SinkExt, StreamExt};
use minicbor::{Decoder, Encoder, data::Type};
use std::{sync::Arc, time::Duration};
use tokio::{
    net::{TcpListener, TcpStream},
    sync::Semaphore,
    task::JoinSet,
    time::timeout,
};
use tokio_tungstenite::{
    accept_hdr_async_with_config, connect_async_with_config,
    tungstenite::{
        Error, Message,
        client::{IntoClientRequest, uri_mode},
        protocol::{CloseFrame, WebSocketConfig, frame::coding::CloseCode},
    },
};
use tokio_util::sync::CancellationToken;

pub fn to_cbor(message: Message) -> Result<Option<Bytes>, Disconnect> {
    Ok(match message {
        Message::Binary(bytes) => {
            let target = legacy::binary_target(&bytes)?;
            if target != 0 {
                // Write the envelope and value once, directly into their final storage.
                let payload = &bytes[8..];
                let capacity = 1
                    + protocol::uint_len(target)
                    + protocol::uint_len(payload.len() as u64)
                    + payload.len();
                let mut e = Encoder::new(Vec::with_capacity(capacity));
                e.array(2)
                    .and_then(|e| e.u64(target))
                    .and_then(|e| e.bytes(payload))
                    .expect("Vec encoding");
                return Ok(Some(e.into_writer().into()));
            }
            Some(match legacy::command(&bytes[8..])? {
                legacy::Command::Authenticate(secret) => byte_request(0, secret),
                legacy::Command::Listen(flags) => uint_request(1, u64::from(flags)),
                // The complete request is always [0, [2, null]].
                legacy::Command::Channels => Bytes::from_static(b"\x82\x00\x82\x02\xf6"),
                legacy::Command::Assign(id) => uint_request(3, id),
                legacy::Command::SetVariable { key, value } => {
                    let capacity = 5
                        + protocol::uint_len(key.len() as u64)
                        + key.len()
                        + protocol::uint_len(value.len() as u64)
                        + value.len();
                    let mut e = Encoder::new(Vec::with_capacity(capacity));
                    e.array(2)
                        .and_then(|e| e.u8(0))
                        .and_then(|e| e.array(2))
                        .and_then(|e| e.u8(4))
                        .and_then(|e| e.array(2))
                        .and_then(|e| e.bytes(key))
                        .and_then(|e| e.bytes(value))
                        .expect("Vec encoding");
                    e.into_writer().into()
                }
                legacy::Command::GetVariable(key) => byte_request(5, key),
                legacy::Command::Ignore => return Ok(None),
            })
        }
        Message::Text(text) => {
            let target = legacy::text_target(&text)?;
            if target == 0 {
                None
            } else {
                // CBOR lengths count UTF-8 bytes; encode directly into final storage.
                let payload = &text[12..];
                let capacity = 1
                    + protocol::uint_len(target)
                    + protocol::uint_len(payload.len() as u64)
                    + payload.len();
                let mut e = Encoder::new(Vec::with_capacity(capacity));
                e.array(2)
                    .and_then(|e| e.u64(target))
                    .and_then(|e| e.str(payload))
                    .expect("Vec encoding");
                Some(e.into_writer().into())
            }
        }
        _ => {
            return Err(Disconnect {
                code: 1003,
                reason: "Type Unsupported",
            });
        }
    })
}

// Encode byte-valued commands directly into their one owned request buffer.
fn byte_request(op: u8, value: &[u8]) -> Bytes {
    let capacity = 3
        + protocol::uint_len(u64::from(op))
        + protocol::uint_len(value.len() as u64)
        + value.len();
    let mut e = Encoder::new(Vec::with_capacity(capacity));
    e.array(2)
        .and_then(|e| e.u8(0))
        .and_then(|e| e.array(2))
        .and_then(|e| e.u8(op))
        .and_then(|e| e.bytes(value))
        .expect("Vec encoding");
    e.into_writer().into()
}

fn uint_request(op: u8, value: u64) -> Bytes {
    let mut e = Encoder::new(Vec::with_capacity(
        3 + protocol::uint_len(u64::from(op)) + protocol::uint_len(value),
    ));
    e.array(2)
        .and_then(|e| e.u8(0))
        .and_then(|e| e.array(2))
        .and_then(|e| e.u8(op))
        .and_then(|e| e.u64(value))
        .expect("Vec encoding");
    e.into_writer().into()
}

/// Convert a complete upstream envelope into an owned legacy message.
///
/// Returned messages do not borrow `bytes`. Binary payloads are copied into a
/// single legacy-format allocation; shared codec receive storage is not mutated.
pub fn from_cbor(bytes: &[u8]) -> Result<Option<Message>> {
    let (sender, value) =
        protocol::parse(bytes).map_err(|_| anyhow::anyhow!("invalid upstream envelope"))?;
    let mut d = Decoder::new(value);
    if sender == BROADCAST {
        let id = d.u64()?;
        anyhow::ensure!(id != 0 && id != BROADCAST, "invalid upstream departed ID");
        return Ok(Some(legacy::disconnect_event(id)));
    }
    if sender == 0 {
        if d.array()? != Some(2) {
            bail!("invalid upstream command reply");
        }
        return Ok(match d.u8()? {
            // Validate acknowledgements even though old clients do not receive them.
            0 => {
                d.bool()?;
                None
            }
            1 => {
                anyhow::ensure!(d.u8()? <= 7, "invalid upstream listener flags");
                None
            }
            3 => {
                let id = d.u64()?;
                anyhow::ensure!(id != 0 && id != BROADCAST, "invalid upstream assigned ID");
                None
            }
            4 => {
                anyhow::ensure!(d.bool()?, "invalid upstream variable acknowledgement");
                None
            }
            2 => Some(channel_reply(&mut d)?),
            200 => {
                if d.array()? != Some(2) {
                    bail!("invalid variable reply");
                }
                let found = d.bool()?;
                let value = if found {
                    match d.datatype()? {
                        Type::Bytes => d.bytes()?,
                        Type::String => d.str()?.as_bytes(),
                        _ => bail!("typed variable requires a CBOR client"),
                    }
                } else {
                    d.null()?;
                    &[]
                };
                Some(legacy::variable_reply(value))
            }
            _ => bail!("unknown upstream command reply"),
        });
    }
    match d.datatype()? {
        Type::Bytes => {
            let payload = d.bytes()?;
            let mut bytes = Vec::with_capacity(8 + payload.len());
            bytes.extend_from_slice(&sender.to_le_bytes());
            bytes.extend_from_slice(payload);
            Ok(Some(Message::Binary(bytes.into())))
        }
        Type::String => {
            let payload = d.str()?;
            let mut text = String::with_capacity(12 + payload.len());
            STANDARD.encode_string(sender.to_le_bytes(), &mut text);
            text.push_str(payload);
            Ok(Some(Message::Text(text.into())))
        }
        _ => bail!("structured payload requires a CBOR client"),
    }
}

// Legacy channel replies put all length-prefixed names before populations.
// Their name block cannot exceed the remaining encoded entries: every entry
// already contains its name, a CBOR string header, array header and population.
fn channel_reply(d: &mut Decoder<'_>) -> Result<Message> {
    let count = u32::try_from(d.array()?.context("indefinite channel list")?)?;
    // Reply array, opcode and list use three items; each channel record needs
    // its own array, name and population. Reject impossible schemas before
    // allocating output, even when their individual elements are valid CBOR.
    anyhow::ensure!(
        u64::from(count) <= (protocol::MAX_ITEMS - 3) / 3,
        "invalid channel entry count"
    );
    // Each representable name needs at most one length byte plus 255 bytes.
    // A malformed oversized name must not inflate the destination allocation.
    let names_bound = (d.input().len() - d.position()).min(count as usize * 256);
    let populations_start = 12 + names_bound;
    // protocol::parse bounds the complete envelope to MAX_ITEMS. Keep the
    // population block after the upper bound on names while decoding once.
    let mut reply = vec![0; populations_start + count as usize * 4];
    reply[8..12].copy_from_slice(&count.to_le_bytes());
    let mut name_offset = 12;
    let mut population_offset = populations_start;
    for _ in 0..count {
        if d.array()? != Some(2) {
            bail!("invalid channel entry");
        }
        let name = d.bytes()?;
        reply[name_offset] = u8::try_from(name.len())?;
        name_offset += 1;
        reply[name_offset..name_offset + name.len()].copy_from_slice(name);
        name_offset += name.len();
        let population = u32::try_from(d.u64()?)?;
        reply[population_offset..population_offset + 4].copy_from_slice(&population.to_le_bytes());
        population_offset += 4;
    }
    reply.copy_within(populations_start.., name_offset);
    reply.truncate(name_offset + count as usize * 4);
    Ok(Message::Binary(reply.into()))
}

/// Bind on loopback by default. Bound admission, handshake/join/write time, and
/// frame sizes independently of the upstream relay's own limits.
pub async fn serve(
    listener: TcpListener,
    upstream: String,
    max_connections: usize,
    shutdown: CancellationToken,
) -> Result<()> {
    serve_with_origin_policy(
        listener,
        upstream,
        max_connections,
        crate::origin::OriginPolicy::default(),
        shutdown,
    )
    .await
}

/// Serve the original wire protocol with an optional browser-origin boundary.
/// Apply the policy at this public ingress; the upstream bridge connection has
/// no browser Origin and must not be relied on to enforce downstream origins.
pub async fn serve_with_origin_policy(
    listener: TcpListener,
    upstream: String,
    max_connections: usize,
    origin_policy: crate::origin::OriginPolicy,
    shutdown: CancellationToken,
) -> Result<()> {
    serve_with_limits(
        listener,
        upstream,
        max_connections,
        0,
        origin_policy,
        shutdown,
    )
    .await
}

/// Check upstream URL syntax and WebSocket scheme without opening a connection.
/// Reachability and TLS availability are checked when a client connects.
pub fn validate_upstream(upstream: &str) -> Result<()> {
    let request = upstream
        .into_client_request()
        .context("invalid legacy upstream URL")?;
    uri_mode(request.uri()).context("invalid legacy upstream URL")?;
    Ok(())
}

/// Check admission counter and semaphore ranges without allocating or binding.
/// Serving repeats this validation; callers may also use it before binding.
pub fn validate_connection_limits(
    max_connections: usize,
    max_connections_per_ip: usize,
) -> Result<()> {
    anyhow::ensure!(
        max_connections_per_ip <= u32::MAX as usize,
        "max-connections-per-ip must be in 0..=4294967295"
    );
    anyhow::ensure!(
        max_connections > 0 && max_connections <= Semaphore::MAX_PERMITS,
        "invalid bridge connection limit"
    );
    Ok(())
}

/// Optional direct-peer admission at the public legacy ingress. Forwarding
/// headers do not change the address observed on the accepted TCP connection.
pub async fn serve_with_limits(
    listener: TcpListener,
    upstream: String,
    max_connections: usize,
    max_connections_per_ip: usize,
    origin_policy: crate::origin::OriginPolicy,
    shutdown: CancellationToken,
) -> Result<()> {
    origin_policy.validate()?;
    validate_upstream(&upstream)?;
    validate_connection_limits(max_connections, max_connections_per_ip)?;
    let slots = Arc::new(Semaphore::new(max_connections));
    let origin_policy = Arc::new(origin_policy);
    let ip_limit = crate::admission::IpLimit::new(max_connections_per_ip);
    let mut tasks = JoinSet::new();
    let mut accept_retry = None;
    loop {
        tokio::select! {
            biased;
            _ = shutdown.cancelled() => break,
            _ = tasks.join_next(), if !tasks.is_empty() => {},
            incoming = async {
                if let Some(deadline) = accept_retry {
                    tokio::time::sleep_until(deadline).await;
                }
                listener.accept().await
            } => {
                let (socket, address) = match incoming {
                    Ok(incoming) => {
                        accept_retry = None;
                        incoming
                    }
                    Err(error) => {
                        let delay = transport::accept_retry_delay(&error);
                        accept_retry = (!delay.is_zero())
                            .then(|| tokio::time::Instant::now() + delay);
                        if !delay.is_zero() {
                            tracing::warn!(%error, "legacy accept failed; retrying in one second");
                        }
                        continue;
                    }
                };
                let Ok(permit) = slots.clone().try_acquire_owned() else { continue; };
                let ip_permit = if let Some(limit) = &ip_limit {
                    let Some(permit) = limit.acquire(address.ip()) else { continue; };
                    Some(permit)
                } else { None };
                let socket = transport::HandshakeStream::new(socket, ip_permit);
                let upstream = upstream.clone(); let token = shutdown.clone();
                let origin_policy = origin_policy.clone();
                tasks.spawn(async move {
                    let _permit = permit;
                    tokio::select! {
                        _ = token.cancelled() => {},
                        result = bridge(socket, upstream, &origin_policy) => { if let Err(error) = result { tracing::debug!(%error, "legacy bridge connection ended"); } }
                    }
                });
            }
        }
    }
    tasks.abort_all();
    while tasks.join_next().await.is_some() {}
    Ok(())
}

// Transport resets have no peer left to notify. Decoder failures get a bounded,
// best-effort Close; their input cannot safely resume a normal Close handshake.
fn frame_error_close(error: &Error) -> Option<CloseFrame> {
    let (code, reason) = match error {
        Error::Capacity(_) => (CloseCode::Size, "Message Too Large"),
        Error::Utf8(_) => (CloseCode::Invalid, "Invalid UTF-8"),
        Error::Protocol(
            tokio_tungstenite::tungstenite::error::ProtocolError::ResetWithoutClosingHandshake,
        ) => return None,
        Error::Protocol(_) => (CloseCode::Protocol, "Protocol Error"),
        _ => return None,
    };
    Some(CloseFrame {
        code,
        reason: reason.into(),
    })
}

async fn bridge(
    socket: transport::HandshakeStream<TcpStream>,
    upstream: String,
    origin_policy: &crate::origin::OriginPolicy,
) -> Result<()> {
    const WAIT: Duration = Duration::from_secs(10);
    socket.get_ref().set_nodelay(true)?;
    let config = WebSocketConfig::default()
        .read_buffer_size(4096)
        .write_buffer_size(4096)
        .max_write_buffer_size(17 * 1024 * 1024)
        .max_message_size(Some(16 * 1024 * 1024));
    let mut legacy = timeout(
        WAIT,
        accept_hdr_async_with_config(
            socket,
            |request: &tokio_tungstenite::tungstenite::handshake::server::Request, response| {
                if origin_policy.allows(request.headers()) {
                    Ok(response)
                } else {
                    Err(crate::origin::forbidden())
                }
            },
            Some(config),
        ),
    )
    .await??;
    legacy.get_mut().handshake_done();
    legacy.set_read_frame_limit(Some(transport::READ_FRAMES_PER_POLL));
    let joined = timeout(WAIT, async {
        loop {
            match legacy
                .next()
                .await
                .context("legacy client left before join")?
            {
                Err(error) => {
                    if let Some(frame) = frame_error_close(&error) {
                        // Framing is no longer trustworthy: flush Close without
                        // interpreting the denied payload as an acknowledgement.
                        let _ = timeout(WAIT, legacy.close(Some(frame))).await;
                        break Ok(None);
                    }
                    return Err(error.into());
                }
                Ok(Message::Binary(bytes)) => break Ok::<_, anyhow::Error>(Some(bytes)),
                Ok(Message::Text(text)) => break Ok(Some(text.into())),
                Ok(Message::Ping(_)) => legacy.flush().await?,
                Ok(Message::Pong(_)) => {}
                Ok(Message::Close(_)) => {
                    transport::acknowledge_close(&mut legacy, WAIT).await;
                    break Ok(None);
                }
                _ => bail!("legacy client left before join"),
            }
        }
    })
    .await;
    let joined = match joined {
        Ok(joined) => joined?,
        Err(error) => {
            transport::initiate_close(
                &mut legacy,
                Some(CloseFrame {
                    code: CloseCode::Policy,
                    reason: "Channel Join Timeout".into(),
                }),
                WAIT,
                None,
            )
            .await;
            return Err(error).context("legacy channel join timeout");
        }
    };
    let Some(joined) = joined else {
        return Ok(());
    };
    if joined.len() > 16 {
        transport::initiate_close(
            &mut legacy,
            Some(CloseFrame {
                code: CloseCode::Protocol,
                reason: "Channel Length Exceeded".into(),
            }),
            WAIT,
            None,
        )
        .await;
        return Ok(());
    }
    // Disable Nagle's ACK-dependent delay for consecutive small relay packets.
    // Match the frontend's small initial buffer without reducing upstream frame limits.
    let upstream_config = WebSocketConfig::default().read_buffer_size(4096);
    // Reuse the one setup-message slot across connection and welcome waits.
    // Reading stops once occupied, preserving FIFO and bounded retention.
    let mut pending = None;
    let connection = timeout(WAIT, async {
        let connection = connect_async_with_config(upstream, Some(upstream_config), true);
        tokio::pin!(connection);
        loop {
            tokio::select! {
                result = &mut connection => break result.map(Some).map_err(anyhow::Error::from),
                incoming = legacy.next(), if pending.is_none() => match incoming {
                    Some(Ok(Message::Ping(_))) => legacy.flush().await?,
                    Some(Ok(Message::Pong(_))) => {},
                    Some(Ok(Message::Close(_))) => {
                        transport::acknowledge_close(&mut legacy, WAIT).await;
                        break Ok(None);
                    }
                    Some(Ok(message)) => pending = Some(message),
                    Some(Err(error)) => {
                        if let Some(frame) = frame_error_close(&error) {
                            let _ = timeout(WAIT, legacy.close(Some(frame))).await;
                        }
                        break Ok(None);
                    }
                    None => break Ok(None),
                },
            }
        }
    })
    .await
    .context("upstream connection timeout")
    .and_then(|result| result);
    let (mut upstream, _) = match connection {
        Ok(Some(connection)) => connection,
        Ok(None) => return Ok(()),
        Err(error) => {
            drop(pending.take());
            transport::initiate_close(
                &mut legacy,
                Some(CloseFrame {
                    code: CloseCode::Again,
                    reason: "Upstream Unavailable".into(),
                }),
                WAIT,
                None,
            )
            .await;
            return Err(error);
        }
    };
    upstream.set_read_frame_limit(Some(transport::READ_FRAMES_PER_POLL));
    let subscription = protocol::byte_string(&joined);
    // The encoded subscription owns its bytes; release the frontend join view.
    drop(joined);
    let welcome = timeout(WAIT, async {
        upstream.send(Message::Binary(subscription)).await?;
        loop {
            tokio::select! {
                incoming = legacy.next(), if pending.is_none() => match incoming {
                    Some(Ok(Message::Ping(_))) => legacy.flush().await?,
                    Some(Ok(Message::Pong(_))) => {},
                    Some(Ok(Message::Close(frame))) => {
                        transport::acknowledge_close(&mut legacy, WAIT).await;
                        // Send Close, but do not let an upstream that withholds
                        // its welcome retain admission waiting for an ACK too.
                        let _ = timeout(WAIT, upstream.close(frame)).await;
                        break Ok(None);
                    }
                    Some(Ok(message)) => pending = Some(message),
                    Some(Err(error)) => {
                        if let Some(frame) = frame_error_close(&error) {
                            let _ = timeout(WAIT, legacy.close(Some(frame))).await;
                        }
                        break Ok(None);
                    }
                    None => break Ok(None),
                },
                incoming = upstream.next() => match incoming.context("upstream closed before welcome")? {
                    Ok(Message::Ping(_)) => upstream.flush().await?,
                    Ok(Message::Pong(_)) => {}
                    Ok(Message::Close(frame)) => {
                        drop(pending.take());
                        transport::acknowledge_close(&mut upstream, WAIT).await;
                        transport::initiate_close(&mut legacy, frame, WAIT, None).await;
                        break Ok(None);
                    }
                    Ok(message) => break Ok::<_, anyhow::Error>(Some(message)),
                    Err(error) => {
                        if let Some(frame) = frame_error_close(&error) {
                            drop(pending.take());
                            transport::initiate_close(&mut legacy, Some(frame), WAIT, None).await;
                            break Ok(None);
                        }
                        return Err(error.into());
                    }
                }
            }
        }
    })
    .await
    .context("upstream welcome timeout")
    .and_then(|result| result);
    let welcome = match welcome {
        Ok(welcome) => welcome,
        Err(error) => {
            drop(pending.take());
            transport::initiate_close(
                &mut legacy,
                Some(CloseFrame {
                    code: CloseCode::Again,
                    reason: "Upstream Unavailable".into(),
                }),
                WAIT,
                None,
            )
            .await;
            return Err(error);
        }
    };
    let Some(welcome) = welcome else {
        return Ok(());
    };
    let id = match &welcome {
        Message::Binary(bytes) => {
            let mut decoder = Decoder::new(bytes);
            match decoder.u64() {
                Ok(id) if id != 0 && id != BROADCAST && decoder.position() == bytes.len() => {
                    Some(id)
                }
                _ => None,
            }
        }
        _ => None,
    };
    // Only the scalar ID survives validation, including during error cleanup.
    drop(welcome);
    let Some(id) = id else {
        drop(pending.take());
        let frame = Some(CloseFrame {
            code: CloseCode::Protocol,
            reason: "Invalid Upstream Welcome".into(),
        });
        tokio::join!(
            transport::initiate_close(&mut upstream, frame.clone(), WAIT, None),
            transport::initiate_close(&mut legacy, frame, WAIT, None),
        );
        return Ok(());
    };
    legacy
        .send(Message::Binary(Bytes::copy_from_slice(&id.to_le_bytes())))
        .await?;
    loop {
        tokio::select! {
            incoming = async {
                match pending.take() {
                    Some(message) => Some(Ok(message)),
                    None => legacy.next().await,
                }
            } => match incoming {
                Some(Ok(Message::Ping(_))) => { timeout(WAIT, legacy.flush()).await??; }
                Some(Ok(Message::Pong(_))) => {}
                Some(Ok(Message::Close(frame))) => {
                    transport::acknowledge_close(&mut legacy, WAIT).await;
                    transport::initiate_close(&mut upstream, frame, WAIT, None).await;
                    break;
                }
                Some(Err(error)) => {
                    if let Some(frame) = frame_error_close(&error) {
                        let _ = timeout(WAIT, legacy.close(Some(frame))).await;
                    }
                    break;
                }
                Some(Ok(message)) => match to_cbor(message) {
                    Ok(Some(packet)) => timeout(WAIT, upstream.send(Message::Binary(packet))).await??,
                    Ok(None) => {},
                    Err(reason) => { transport::initiate_close(&mut legacy, Some(CloseFrame { code: reason.code.into(), reason: reason.reason.into() }), WAIT, None).await; break; }
                }
                _ => break,
            },
            incoming = upstream.next() => match incoming {
                Some(Ok(Message::Binary(bytes))) => match from_cbor(&bytes) {
                    Ok(Some(message)) => timeout(WAIT, legacy.send(message)).await??,
                    Ok(None) => {},
                    Err(_) => { drop(bytes); drop(pending.take()); transport::initiate_close(&mut legacy, Some(CloseFrame { code: CloseCode::Unsupported, reason: "Value Requires CBOR Client".into() }), WAIT, None).await; break; }
                }
                Some(Err(error)) => {
                    if let Some(frame) = frame_error_close(&error) {
                        drop(pending.take());
                        transport::initiate_close(&mut legacy, Some(frame), WAIT, None).await;
                    }
                    break;
                }
                Some(Ok(Message::Text(text))) => {
                    drop(text);
                    drop(pending.take());
                    transport::initiate_close(&mut legacy, Some(CloseFrame {
                        code: CloseCode::Protocol,
                        reason: "Invalid Upstream Message".into(),
                    }), WAIT, None).await;
                    break;
                }
                Some(Ok(Message::Ping(_))) => { timeout(WAIT, upstream.flush()).await??; }
                Some(Ok(Message::Pong(_))) => {},
                Some(Ok(Message::Close(frame))) => {
                    drop(pending.take());
                    transport::acknowledge_close(&mut upstream, WAIT).await;
                    transport::initiate_close(&mut legacy, frame, WAIT, None).await;
                    break;
                }
                _ => break,
            }
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn disconnect_events_preserve_valid_ids_and_reject_reserved_departures() {
        for id in [
            1,
            23,
            24,
            255,
            256,
            65_535,
            65_536,
            1u64 << 32,
            u64::MAX - 1,
        ] {
            let mut expected = vec![255; 8];
            expected.extend_from_slice(&id.to_le_bytes());
            assert_eq!(
                from_cbor(&protocol::envelope(BROADCAST, &protocol::uint(id))).unwrap(),
                Some(Message::Binary(expected.into()))
            );
        }
        for id in [0, BROADCAST] {
            assert!(from_cbor(&protocol::envelope(BROADCAST, &protocol::uint(id))).is_err());
        }
        for value in [b"\xf6".as_slice(), b"\xf4", b"\x20", b"\x60", b"\x80"] {
            assert!(from_cbor(&protocol::envelope(BROADCAST, value)).is_err());
        }
    }

    #[test]
    fn upstream_acknowledgements_validate_and_remain_invisible_to_legacy_clients() {
        for value in [false, true] {
            let encoded = if value { b"\xf5" } else { b"\xf4" };
            assert!(from_cbor(&protocol::reply(0, encoded)).unwrap().is_none());
        }
        for flags in 0..=7 {
            assert!(
                from_cbor(&protocol::reply(1, &protocol::uint(flags)))
                    .unwrap()
                    .is_none()
            );
        }
        for id in [
            1,
            23,
            24,
            255,
            256,
            65_535,
            65_536,
            1u64 << 32,
            u64::MAX - 1,
        ] {
            assert!(
                from_cbor(&protocol::reply(3, &protocol::uint(id)))
                    .unwrap()
                    .is_none()
            );
        }
        assert!(from_cbor(&protocol::reply(4, b"\xf5")).unwrap().is_none());
    }

    #[test]
    fn upstream_acknowledgements_reject_wrong_types_and_impossible_results() {
        for op in [0, 1, 3, 4] {
            for value in [b"\xf6".as_slice(), b"\x40", b"\x60", b"\x80", b"\xa0"] {
                assert!(
                    from_cbor(&protocol::reply(op, value)).is_err(),
                    "op {op}, value {value:?}"
                );
            }
        }
        for op in [0, 4] {
            assert!(from_cbor(&protocol::reply(op, b"\x00")).is_err());
        }
        for op in [1, 3] {
            for value in [b"\xf4", b"\xf5", b"\x20"] {
                assert!(from_cbor(&protocol::reply(op, value)).is_err());
            }
        }
        for flags in [8, 255, 256, u64::MAX] {
            assert!(from_cbor(&protocol::reply(1, &protocol::uint(flags))).is_err());
        }
        for id in [0, BROADCAST] {
            assert!(from_cbor(&protocol::reply(3, &protocol::uint(id))).is_err());
        }
        assert!(from_cbor(&protocol::reply(4, b"\xf4")).is_err());
    }

    #[test]
    fn missing_variable_replies_require_null_and_preserve_present_values() {
        let mut empty = vec![0; 8];
        empty.push(200);
        assert_eq!(
            from_cbor(&protocol::reply(200, b"\x82\xf4\xf6")).unwrap(),
            Some(Message::Binary(empty.clone().into()))
        );
        for invalid in [
            b"\xf4".as_slice(),
            b"\xf5",
            b"\x00",
            b"\x40",
            b"\x60",
            b"\x80",
            b"\xa0",
        ] {
            let mut value = vec![0x82, 0xf4];
            value.extend_from_slice(invalid);
            assert!(from_cbor(&protocol::reply(200, &value)).is_err());
        }
        for (encoded, payload) in [
            (b"\x82\xf5\x42ok".as_slice(), b"ok".as_slice()),
            (b"\x82\xf5\x40", b""),
            (b"\x82\xf5\x60", b""),
            (b"\x82\xf5\x62\xcf\x80", "π".as_bytes()),
        ] {
            let mut expected = empty.clone();
            expected.extend_from_slice(payload);
            assert_eq!(
                from_cbor(&protocol::reply(200, encoded)).unwrap(),
                Some(Message::Binary(expected.into()))
            );
        }
        // Present structured/null values still require a native CBOR client.
        assert!(from_cbor(&protocol::reply(200, b"\x82\xf5\xf6")).is_err());
    }

    #[test]
    fn channel_replies_preserve_legacy_layout_and_reject_unrepresentable_fields() {
        for count in [0, 1, 64, 1024, (protocol::MAX_ITEMS - 3) / 3] {
            let mut e = Encoder::new(Vec::new());
            e.array(2)
                .unwrap()
                .u8(0)
                .unwrap()
                .array(2)
                .unwrap()
                .u8(2)
                .unwrap()
                .array(count)
                .unwrap();
            let mut expected = vec![0; 8];
            expected.extend_from_slice(&(count as u32).to_le_bytes());
            for i in 0..count {
                let name: Vec<_> = (0..(i % 256)).map(|j| j as u8).collect();
                e.array(2)
                    .unwrap()
                    .bytes(&name)
                    .unwrap()
                    .u32(u32::MAX - i as u32)
                    .unwrap();
                expected.push(name.len() as u8);
                expected.extend_from_slice(&name);
            }
            for i in 0..count {
                expected.extend_from_slice(&(u32::MAX - i as u32).to_le_bytes());
            }
            let Some(Message::Binary(reply)) = from_cbor(&e.into_writer()).unwrap() else {
                panic!("legacy channel reply must be binary");
            };
            assert_eq!(reply.as_ref(), expected.as_slice());
        }
        for (name, population) in [
            (vec![0; 256], 1),
            (vec![0; 1024 * 1024], 1),
            (vec![0; 255], u32::MAX as u64 + 1),
        ] {
            let mut e = Encoder::new(Vec::new());
            e.array(2)
                .unwrap()
                .u8(0)
                .unwrap()
                .array(2)
                .unwrap()
                .u8(2)
                .unwrap()
                .array(1)
                .unwrap()
                .array(2)
                .unwrap()
                .bytes(&name)
                .unwrap()
                .u64(population)
                .unwrap();
            assert!(from_cbor(&e.into_writer()).is_err());
        }
    }

    #[tokio::test]
    async fn upstream_rejection_before_welcome_reaches_legacy_and_releases_the_slot() {
        timeout(Duration::from_secs(2), async {
            let frames = [
                Some(CloseFrame {
                    code: CloseCode::Policy,
                    reason: "Join Denied".into(),
                }),
                None,
            ];
            let upstream = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let upstream_url = format!("ws://{}", upstream.local_addr().unwrap());
            let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let url = format!("ws://{}", listener.local_addr().unwrap());
            let shutdown = CancellationToken::new();
            let mut tasks = JoinSet::new();
            let requested = frames.clone();
            tasks.spawn(async move {
                for frame in requested {
                    let (stream, _) = upstream.accept().await.unwrap();
                    let mut ws = tokio_tungstenite::accept_async(stream).await.unwrap();
                    let Some(Ok(Message::Binary(join))) = ws.next().await else {
                        panic!("missing upstream join");
                    };
                    assert_eq!(protocol::join(&join).unwrap(), b"welcome");
                    assert!(
                        transport::initiate_close(&mut ws, frame, Duration::from_secs(1), None)
                            .await
                    );
                }
            });
            let token = shutdown.clone();
            tasks.spawn(async move {
                serve(listener, upstream_url, 1, token).await.unwrap();
            });
            for expected in frames {
                let (mut ws, _) = tokio_tungstenite::connect_async(&url).await.unwrap();
                ws.send(Message::Binary(Bytes::from_static(b"welcome")))
                    .await
                    .unwrap();
                let Some(Ok(Message::Close(actual))) = ws.next().await else {
                    panic!("upstream rejection was not relayed before welcome");
                };
                match (expected, actual) {
                    (Some(expected), Some(actual)) => {
                        assert_eq!(actual.code, expected.code);
                        assert_eq!(actual.reason, expected.reason);
                    }
                    (None, None) => {}
                    _ => panic!("upstream close payload changed"),
                }
                assert!(transport::acknowledge_close(&mut ws, Duration::from_secs(1)).await);
                assert!(
                    ws.next().await.is_none(),
                    "bridge did not retire the rejected connection"
                );
            }
            shutdown.cancel();
            while let Some(result) = tasks.join_next().await {
                result.unwrap();
            }
        })
        .await
        .expect("early rejection and single-slot reuse must be prompt");
    }

    #[tokio::test]
    async fn upstream_ping_and_pong_before_welcome_preserve_join_and_routing() {
        timeout(Duration::from_secs(2), async {
            let upstream = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let upstream_url = format!("ws://{}", upstream.local_addr().unwrap());
            let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let url = format!("ws://{}", listener.local_addr().unwrap());
            let shutdown = CancellationToken::new();
            let mut tasks = JoinSet::new();
            tasks.spawn(async move {
                let (stream, _) = upstream.accept().await.unwrap();
                let mut ws = tokio_tungstenite::accept_async(stream).await.unwrap();
                assert!(matches!(ws.next().await, Some(Ok(Message::Binary(_)))));
                ws.send(Message::Pong(Bytes::from_static(b"unsolicited")))
                    .await
                    .unwrap();
                ws.send(Message::Ping(Bytes::from_static(b"probe")))
                    .await
                    .unwrap();
                assert_eq!(
                    ws.next().await.unwrap().unwrap(),
                    Message::Pong(Bytes::from_static(b"probe"))
                );
                ws.send(Message::Binary(protocol::uint(42))).await.unwrap();
                let expected = protocol::envelope(42, &protocol::byte_string(&[17, 34]));
                assert_eq!(
                    ws.next().await.unwrap().unwrap(),
                    Message::Binary(expected.clone())
                );
                ws.send(Message::Binary(expected)).await.unwrap();
                assert!(
                    transport::initiate_close(&mut ws, None, Duration::from_secs(1), None).await
                );
            });
            let token = shutdown.clone();
            tasks.spawn(async move {
                serve(listener, upstream_url, 1, token).await.unwrap();
            });
            let (mut ws, _) = tokio_tungstenite::connect_async(url).await.unwrap();
            ws.send(Message::Binary(Bytes::from_static(b"welcome")))
                .await
                .unwrap();
            assert_eq!(
                ws.next().await.unwrap().unwrap(),
                Message::Binary(Bytes::copy_from_slice(&42u64.to_le_bytes()))
            );
            let mut packet = 42u64.to_le_bytes().to_vec();
            packet.extend_from_slice(&[17, 34]);
            ws.send(Message::Binary(Bytes::from(packet.clone())))
                .await
                .unwrap();
            assert_eq!(
                ws.next().await.unwrap().unwrap(),
                Message::Binary(Bytes::from(packet))
            );
            assert!(matches!(ws.next().await, Some(Ok(Message::Close(None)))));
            assert!(transport::acknowledge_close(&mut ws, Duration::from_secs(1)).await);
            assert!(ws.next().await.is_none());
            shutdown.cancel();
            while let Some(result) = tasks.join_next().await {
                result.unwrap();
            }
        })
        .await
        .expect("pre-welcome control frames must not prevent routing");
    }

    #[tokio::test]
    async fn upstream_text_after_welcome_closes_cleanly_and_releases_the_slot() {
        timeout(Duration::from_secs(2), async {
            let upstream = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let upstream_url = format!("ws://{}", upstream.local_addr().unwrap());
            let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let url = format!("ws://{}", listener.local_addr().unwrap());
            let shutdown = CancellationToken::new();
            let mut tasks = JoinSet::new();
            tasks.spawn(async move {
                for _ in 0..2 {
                    let (stream, _) = upstream.accept().await.unwrap();
                    let mut ws = tokio_tungstenite::accept_async(stream).await.unwrap();
                    assert!(matches!(ws.next().await, Some(Ok(Message::Binary(_)))));
                    ws.send(Message::Binary(protocol::uint(42))).await.unwrap();
                    ws.send(Message::Text("unexpected".into())).await.unwrap();
                    // Keep the upstream open until the bridge retires it.
                    while let Some(message) = ws.next().await {
                        if message.is_err() {
                            break;
                        }
                    }
                }
            });
            let token = shutdown.clone();
            tasks.spawn(async move {
                serve(listener, upstream_url, 1, token).await.unwrap();
            });
            for _ in 0..2 {
                let (mut ws, _) = tokio_tungstenite::connect_async(&url).await.unwrap();
                ws.send(Message::Binary(Bytes::from_static(b"fault")))
                    .await
                    .unwrap();
                assert_eq!(
                    ws.next().await.unwrap().unwrap(),
                    Message::Binary(Bytes::copy_from_slice(&42u64.to_le_bytes()))
                );
                let Some(Ok(Message::Close(Some(frame)))) = ws.next().await else {
                    panic!("unexpected upstream text caused an unclean legacy disconnect");
                };
                assert_eq!(frame.code, CloseCode::Protocol);
                assert_eq!(frame.reason, "Invalid Upstream Message");
                assert!(transport::acknowledge_close(&mut ws, Duration::from_secs(1)).await);
                assert!(ws.next().await.is_none());
            }
            shutdown.cancel();
            while let Some(result) = tasks.join_next().await {
                result.unwrap();
            }
        })
        .await
        .expect("upstream text rejection and single-slot reuse must be prompt");
    }

    #[tokio::test]
    async fn upstream_frame_errors_close_legacy_cleanly_before_and_after_welcome() {
        use tokio::io::AsyncWriteExt;

        timeout(Duration::from_secs(2), async {
            // Invalid opcode, invalid text, masked server frame, oversized frame
            // declaration. No large body is needed to exercise capacity rejection.
            let faults: &[(&[u8], CloseCode, &str)] = &[
                (&[0x83, 0], CloseCode::Protocol, "Protocol Error"),
                (&[0x81, 1, 0xff], CloseCode::Invalid, "Invalid UTF-8"),
                (&[0x82, 0x80, 0, 0, 0, 0], CloseCode::Protocol, "Protocol Error"),
                (&[0x82, 0x7f, 0, 0, 0, 0, 1, 0, 0, 1], CloseCode::Size, "Message Too Large"),
            ];
            let upstream = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let upstream_url = format!("ws://{}", upstream.local_addr().unwrap());
            let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let url = format!("ws://{}", listener.local_addr().unwrap());
            let shutdown = CancellationToken::new();
            let mut tasks = JoinSet::new();
            tasks.spawn(async move {
                for welcomed in [false, true] {
                    for &(wire, _, _) in faults {
                        let (stream, _) = upstream.accept().await.unwrap();
                        let mut ws = tokio_tungstenite::accept_async(stream).await.unwrap();
                        assert!(matches!(ws.next().await, Some(Ok(Message::Binary(_)))));
                        if welcomed {
                            ws.send(Message::Binary(protocol::uint(42))).await.unwrap();
                        }
                        ws.get_mut().write_all(wire).await.unwrap();
                        // The faulty transport stays open until the bridge retires it.
                        while let Some(message) = ws.next().await {
                            if message.is_err() { break; }
                        }
                    }
                }
            });
            let token = shutdown.clone();
            tasks.spawn(async move { serve(listener, upstream_url, 1, token).await.unwrap(); });
            for welcomed in [false, true] {
                for &(_, code, reason) in faults {
                    let (mut ws, _) = tokio_tungstenite::connect_async(&url).await.unwrap();
                    ws.send(Message::Binary(Bytes::from_static(b"fault"))).await.unwrap();
                    if welcomed {
                        assert_eq!(ws.next().await.unwrap().unwrap(), Message::Binary(Bytes::copy_from_slice(&42u64.to_le_bytes())));
                    }
                    let received = ws.next().await;
                    let Some(Ok(Message::Close(Some(frame)))) = received else {
                        panic!("upstream framing failure caused unclean legacy retirement: welcomed={welcomed}, code={code:?}, received={received:?}");
                    };
                    assert_eq!(frame.code, code);
                    assert_eq!(frame.reason, reason);
                    assert!(transport::acknowledge_close(&mut ws, Duration::from_secs(1)).await);
                    assert!(ws.next().await.is_none(), "bridge did not retire after Close acknowledgement");
                }
            }
            shutdown.cancel();
            while let Some(result) = tasks.join_next().await { result.unwrap(); }
        }).await.expect("eight upstream frame faults and one-slot reuse must be prompt");
    }

    #[tokio::test]
    async fn upstream_fragment_trains_yield_before_welcome_and_forwarding_complete() {
        use std::{
            future::Future,
            sync::atomic::{AtomicBool, AtomicUsize, Ordering::Relaxed},
        };
        use tokio::io::AsyncWriteExt;

        timeout(Duration::from_secs(2), async {
            let upstream = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let upstream_url = format!("ws://{}", upstream.local_addr().unwrap());
            let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let url = format!("ws://{}", listener.local_addr().unwrap());
            let counting = Arc::new(AtomicBool::new(false));
            let polls = Arc::new(AtomicUsize::new(0));
            let (continue_send, continue_receive) = tokio::sync::oneshot::channel();
            let mut tasks = JoinSet::new();
            let enabled = counting.clone();
            tasks.spawn(async move {
                let (stream, _) = upstream.accept().await.unwrap();
                let mut ws = tokio_tungstenite::accept_async(stream).await.unwrap();
                assert!(matches!(ws.next().await, Some(Ok(Message::Binary(_)))));
                let fragment = |packet: &[u8]| {
                    let mut train = Vec::new();
                    for frame in 0..transport::READ_FRAMES_PER_POLL.get() * 2 {
                        train.extend_from_slice(&[if frame == 0 { 2 } else { 0 }, 0]);
                    }
                    train.extend_from_slice(&[0x80, packet.len() as u8]);
                    train.extend_from_slice(packet);
                    train
                };
                // Each train is completely written before counting begins.
                // Empty continuations consume no application bytes.
                ws.get_mut()
                    .write_all(&fragment(&protocol::uint(42)))
                    .await
                    .unwrap();
                enabled.store(true, Relaxed);
                continue_receive.await.unwrap();
                let packet = protocol::envelope(42, &protocol::byte_string(&[17, 34]));
                ws.get_mut().write_all(&fragment(&packet)).await.unwrap();
                enabled.store(true, Relaxed);
                assert!(matches!(ws.next().await, Some(Ok(Message::Close(_)))));
                assert!(transport::acknowledge_close(&mut ws, Duration::from_secs(1)).await);
            });
            let enabled = counting.clone();
            let observed = polls.clone();
            tasks.spawn(async move {
                let (socket, _) = listener.accept().await.unwrap();
                let policy = crate::origin::OriginPolicy::default();
                let mut connection = Box::pin(bridge(
                    transport::HandshakeStream::new(socket, None),
                    upstream_url,
                    &policy,
                ));
                futures_util::future::poll_fn(|cx| {
                    if enabled.load(Relaxed) {
                        observed.fetch_add(1, Relaxed);
                    }
                    connection.as_mut().poll(cx)
                })
                .await
                .unwrap();
            });
            let (mut ws, _) = tokio_tungstenite::connect_async(&url).await.unwrap();
            ws.send(Message::Binary(Bytes::from_static(b"fragments")))
                .await
                .unwrap();
            assert_eq!(
                ws.next().await.unwrap().unwrap(),
                Message::Binary(Bytes::copy_from_slice(&42u64.to_le_bytes()))
            );
            counting.store(false, Relaxed);
            let welcome_polls = polls.swap(0, Relaxed);
            assert!(welcome_polls >= 3, "upstream welcome parsed the fragment train without yielding: {welcome_polls} polls");
            continue_send.send(()).unwrap();
            let mut expected = 42u64.to_le_bytes().to_vec();
            expected.extend_from_slice(&[17, 34]);
            assert_eq!(
                ws.next().await.unwrap().unwrap(),
                Message::Binary(expected.into())
            );
            counting.store(false, Relaxed);
            let forwarding_polls = polls.load(Relaxed);
            assert!(forwarding_polls >= 3, "upstream forwarding parsed the fragment train without yielding: {forwarding_polls} polls");
            eprintln!("fragment_poll_counts welcome={welcome_polls} forwarding={forwarding_polls}");
            assert!(transport::initiate_close(&mut ws, None, Duration::from_secs(1), None).await);
            assert!(ws.next().await.is_none());
            while let Some(result) = tasks.join_next().await {
                result.unwrap();
            }
        })
        .await
        .expect("fragment scheduling and exact output must complete promptly");
    }

    async fn frontend_pipeline_before_welcome(before_upgrade: bool) {
        timeout(Duration::from_secs(2), async {
            for text in [false, true] {
                let upstream = TcpListener::bind("127.0.0.1:0").await.unwrap();
                let upstream_url = format!("ws://{}", upstream.local_addr().unwrap());
                let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
                let url = format!("ws://{}", listener.local_addr().unwrap());
                let shutdown = CancellationToken::new();
                let (joined, wait_join) = tokio::sync::oneshot::channel();
                let (welcome, wait_welcome) = tokio::sync::oneshot::channel();
                let mut tasks = JoinSet::new();
                tasks.spawn(async move {
                    let (stream, _) = upstream.accept().await.unwrap();
                    let mut ws = if before_upgrade {
                        // The request has reached TCP, but no HTTP response is sent.
                        assert_eq!(stream.peek(&mut [0; 1]).await.unwrap(), 1);
                        joined.send(()).unwrap();
                        wait_welcome.await.unwrap();
                        let mut ws = tokio_tungstenite::accept_async(stream).await.unwrap();
                        assert!(matches!(ws.next().await, Some(Ok(Message::Binary(_)))));
                        ws
                    } else {
                        let mut ws = tokio_tungstenite::accept_async(stream).await.unwrap();
                        assert!(matches!(ws.next().await, Some(Ok(Message::Binary(_)))));
                        joined.send(()).unwrap();
                        wait_welcome.await.unwrap();
                        ws
                    };
                    ws.send(Message::Binary(protocol::uint(42))).await.unwrap();
                    for value in ["first-π", "second-π"] {
                        let encoded = if text {
                            protocol::text(value)
                        } else {
                            protocol::byte_string(value.as_bytes())
                        };
                        let expected = Message::Binary(protocol::envelope(42, &encoded));
                        assert_eq!(ws.next().await.unwrap().unwrap(), expected);
                        ws.send(expected).await.unwrap();
                    }
                    assert!(matches!(ws.next().await, Some(Ok(Message::Close(_)))));
                    assert!(transport::acknowledge_close(&mut ws, Duration::from_secs(1)).await);
                });
                let token = shutdown.clone();
                tasks.spawn(async move {
                    serve(listener, upstream_url, 1, token).await.unwrap();
                });
                let (mut ws, _) = tokio_tungstenite::connect_async(&url).await.unwrap();
                ws.send(Message::Binary(Bytes::from_static(b"pipeline")))
                    .await
                    .unwrap();
                wait_join.await.unwrap();
                ws.send(Message::Ping(Bytes::from_static(b"waiting")))
                    .await
                    .unwrap();
                assert_eq!(
                    ws.next().await.unwrap().unwrap(),
                    Message::Pong(Bytes::from_static(b"waiting"))
                );
                let messages: Vec<_> = ["first-π", "second-π"]
                    .into_iter()
                    .map(|value| {
                        if text {
                            Message::Text(
                                format!("{}{value}", STANDARD.encode(42u64.to_le_bytes())).into(),
                            )
                        } else {
                            Message::Binary(
                                [42u64.to_le_bytes().as_slice(), value.as_bytes()]
                                    .concat()
                                    .into(),
                            )
                        }
                    })
                    .collect();
                for message in &messages {
                    ws.send(message.clone()).await.unwrap();
                }
                tokio::task::yield_now().await;
                welcome.send(()).unwrap();
                assert_eq!(
                    ws.next().await.unwrap().unwrap(),
                    Message::Binary(Bytes::copy_from_slice(&42u64.to_le_bytes()))
                );
                for message in messages {
                    assert_eq!(ws.next().await.unwrap().unwrap(), message);
                }
                assert!(
                    transport::initiate_close(&mut ws, None, Duration::from_secs(1), None).await
                );
                shutdown.cancel();
                while let Some(result) = tasks.join_next().await {
                    result.unwrap();
                }
            }
        })
        .await
        .expect("pre-welcome Ping and pipelined binary/text FIFO must complete promptly");
    }

    #[tokio::test]
    async fn frontend_ping_and_pipelined_packets_preserve_welcome_and_fifo() {
        frontend_pipeline_before_welcome(false).await;
    }

    #[tokio::test]
    async fn frontend_ping_and_pipeline_during_upstream_upgrade_preserve_fifo() {
        frontend_pipeline_before_welcome(true).await;
    }

    async fn frontend_retirement_during_upstream_upgrade_recovers(abrupt: bool) {
        use tokio::io::AsyncReadExt;

        timeout(Duration::from_secs(2), async {
            let upstream = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let upstream_url = format!("ws://{}", upstream.local_addr().unwrap());
            let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let url = format!("ws://{}", listener.local_addr().unwrap());
            let shutdown = CancellationToken::new();
            let (started, wait_started) = tokio::sync::oneshot::channel();
            let (retired, wait_retired) = tokio::sync::oneshot::channel();
            let mut tasks = JoinSet::new();
            tasks.spawn(async move {
                let (mut stream, _) = upstream.accept().await.unwrap();
                let mut request = Vec::new();
                while !request.ends_with(b"\r\n\r\n") {
                    request.push(stream.read_u8().await.unwrap());
                }
                assert!(request.starts_with(b"GET / HTTP/1.1\r\n"));
                started.send(()).unwrap();
                assert_eq!(stream.read(&mut [0; 1]).await.unwrap(), 0);
                retired.send(()).unwrap();
                let (stream, _) = upstream.accept().await.unwrap();
                let mut ws = tokio_tungstenite::accept_async(stream).await.unwrap();
                assert!(matches!(ws.next().await, Some(Ok(Message::Binary(_)))));
                ws.send(Message::Binary(protocol::uint(42))).await.unwrap();
                assert!(matches!(ws.next().await, Some(Ok(Message::Close(_)))));
                assert!(transport::acknowledge_close(&mut ws, Duration::from_secs(1)).await);
            });
            let token = shutdown.clone();
            tasks.spawn(async move {
                serve(listener, upstream_url, 1, token).await.unwrap();
            });
            let (mut ws, _) = tokio_tungstenite::connect_async(&url).await.unwrap();
            ws.send(Message::Binary(Bytes::from_static(b"upgrade-cancel")))
                .await
                .unwrap();
            wait_started.await.unwrap();
            if abrupt {
                drop(ws);
            } else {
                assert!(
                    transport::initiate_close(
                        &mut ws,
                        Some(CloseFrame {
                            code: CloseCode::Normal,
                            reason: "cancel upgrade".into(),
                        }),
                        Duration::from_secs(1),
                        None
                    )
                    .await
                );
                drop(ws);
            }
            wait_retired.await.unwrap();
            let (mut recovered, _) = tokio_tungstenite::connect_async(&url).await.unwrap();
            recovered
                .send(Message::Binary(Bytes::from_static(b"upgrade-cancel")))
                .await
                .unwrap();
            assert_eq!(
                recovered.next().await.unwrap().unwrap(),
                Message::Binary(Bytes::copy_from_slice(&42u64.to_le_bytes()))
            );
            assert!(
                transport::initiate_close(&mut recovered, None, Duration::from_secs(1), None).await
            );
            shutdown.cancel();
            while let Some(result) = tasks.join_next().await {
                result.unwrap();
            }
        })
        .await
        .expect(
            "frontend retirement must cancel a stalled upstream upgrade and recover the only slot",
        );
    }

    #[tokio::test]
    async fn frontend_close_during_upstream_upgrade_releases_the_only_slot() {
        frontend_retirement_during_upstream_upgrade_recovers(false).await;
    }

    #[tokio::test]
    async fn frontend_eof_during_upstream_upgrade_releases_the_only_slot() {
        frontend_retirement_during_upstream_upgrade_recovers(true).await;
    }

    async fn frontend_retirement_before_welcome_recovers(abrupt: bool) {
        timeout(Duration::from_secs(2), async {
            let upstream = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let upstream_url = format!("ws://{}", upstream.local_addr().unwrap());
            let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let url = format!("ws://{}", listener.local_addr().unwrap());
            let shutdown = CancellationToken::new();
            let (joined, wait_join) = tokio::sync::oneshot::channel();
            let (retired, wait_retired) = tokio::sync::oneshot::channel();
            let mut tasks = JoinSet::new();
            tasks.spawn(async move {
                let (stream, _) = upstream.accept().await.unwrap();
                let mut ws = tokio_tungstenite::accept_async(stream).await.unwrap();
                assert!(matches!(ws.next().await, Some(Ok(Message::Binary(_)))));
                joined.send(()).unwrap();
                let end = ws.next().await;
                if !abrupt {
                    let Some(Ok(Message::Close(Some(frame)))) = end else {
                        panic!("frontend Close was not forwarded before welcome: {end:?}");
                    };
                    assert_eq!(frame.code, CloseCode::Normal);
                    assert_eq!(frame.reason, "cancel join");
                } else {
                    assert!(end.is_none() || matches!(end, Some(Err(_))));
                }
                drop(ws);
                retired.send(()).unwrap();
                let (stream, _) = upstream.accept().await.unwrap();
                let mut ws = tokio_tungstenite::accept_async(stream).await.unwrap();
                assert!(matches!(ws.next().await, Some(Ok(Message::Binary(_)))));
                ws.send(Message::Binary(protocol::uint(42))).await.unwrap();
                assert!(matches!(ws.next().await, Some(Ok(Message::Close(_)))));
                assert!(transport::acknowledge_close(&mut ws, Duration::from_secs(1)).await);
            });
            let token = shutdown.clone();
            tasks.spawn(async move {
                serve(listener, upstream_url, 1, token).await.unwrap();
            });
            let (mut ws, _) = tokio_tungstenite::connect_async(&url).await.unwrap();
            ws.send(Message::Binary(Bytes::from_static(b"cancel-join")))
                .await
                .unwrap();
            wait_join.await.unwrap();
            if abrupt {
                drop(ws);
            } else {
                assert!(
                    transport::initiate_close(
                        &mut ws,
                        Some(CloseFrame {
                            code: CloseCode::Normal,
                            reason: "cancel join".into(),
                        }),
                        Duration::from_secs(1),
                        None
                    )
                    .await
                );
                drop(ws);
            }
            wait_retired.await.unwrap();
            let (mut recovered, _) = tokio_tungstenite::connect_async(&url).await.unwrap();
            recovered
                .send(Message::Binary(Bytes::from_static(b"cancel-join")))
                .await
                .unwrap();
            assert_eq!(
                recovered.next().await.unwrap().unwrap(),
                Message::Binary(Bytes::copy_from_slice(&42u64.to_le_bytes()))
            );
            assert!(
                transport::initiate_close(&mut recovered, None, Duration::from_secs(1), None).await
            );
            shutdown.cancel();
            while let Some(result) = tasks.join_next().await {
                result.unwrap();
            }
        })
        .await
        .expect("frontend retirement must not wait for the upstream welcome deadline");
    }

    #[tokio::test]
    async fn frontend_close_before_welcome_releases_the_only_slot() {
        frontend_retirement_before_welcome_recovers(false).await;
    }

    #[tokio::test]
    async fn frontend_eof_before_welcome_releases_the_only_slot() {
        frontend_retirement_before_welcome_recovers(true).await;
    }

    #[tokio::test]
    async fn frontend_join_timeout_closes_cleanly_and_recovers_the_only_slot() {
        use std::sync::atomic::{AtomicBool, Ordering::Relaxed};

        timeout(Duration::from_secs(14), async {
            let upstream = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let upstream_url = format!("ws://{}", upstream.local_addr().unwrap());
            let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let url = format!("ws://{}", listener.local_addr().unwrap());
            let shutdown = CancellationToken::new();
            let connected = Arc::new(AtomicBool::new(false));
            let observed = connected.clone();
            let mut tasks = JoinSet::new();
            tasks.spawn(async move {
                let (stream, _) = upstream.accept().await.unwrap();
                observed.store(true, Relaxed);
                let mut ws = tokio_tungstenite::accept_async(stream).await.unwrap();
                let Some(Ok(Message::Binary(join))) = ws.next().await else {
                    panic!("missing recovered subscription");
                };
                assert_eq!(protocol::join(&join).unwrap(), b"join-timeout");
                ws.send(Message::Binary(protocol::uint(42))).await.unwrap();
                assert!(matches!(ws.next().await, Some(Ok(Message::Close(_)))));
                assert!(transport::acknowledge_close(&mut ws, Duration::from_secs(1)).await);
            });
            let token = shutdown.clone();
            tasks.spawn(async move {
                serve(listener, upstream_url, 1, token).await.unwrap();
            });
            let (mut idle, _) = tokio_tungstenite::connect_async(&url).await.unwrap();
            let started = tokio::time::Instant::now();
            let received = idle.next().await;
            let Some(Ok(Message::Close(Some(frame)))) = received else {
                panic!("join timeout must send a clean Close: {received:?}");
            };
            assert_eq!(frame.code, CloseCode::Policy);
            assert_eq!(frame.reason, "Channel Join Timeout");
            assert!(started.elapsed() >= Duration::from_secs(9));
            assert!(
                !connected.load(Relaxed),
                "an unjoined client must not open upstream TCP"
            );
            assert!(transport::acknowledge_close(&mut idle, Duration::from_secs(1)).await);
            drop(idle);
            let (mut recovered, _) = tokio_tungstenite::connect_async(&url).await.unwrap();
            recovered
                .send(Message::Binary(Bytes::from_static(b"join-timeout")))
                .await
                .unwrap();
            assert_eq!(
                recovered.next().await.unwrap().unwrap(),
                Message::Binary(Bytes::copy_from_slice(&42u64.to_le_bytes()))
            );
            assert!(
                transport::initiate_close(&mut recovered, None, Duration::from_secs(1), None).await
            );
            shutdown.cancel();
            while let Some(result) = tasks.join_next().await {
                result.unwrap();
            }
        })
        .await
        .expect("join timeout, clean Close and one-slot recovery must stay bounded");
    }

    async fn welcome_failure_closes_and_recovers(stalled: bool) {
        timeout(Duration::from_secs(14), async {
            let upstream = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let upstream_url = format!("ws://{}", upstream.local_addr().unwrap());
            let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let url = format!("ws://{}", listener.local_addr().unwrap());
            let shutdown = CancellationToken::new();
            let mut tasks = JoinSet::new();
            tasks.spawn(async move {
                let (stream, _) = upstream.accept().await.unwrap();
                let mut ws = tokio_tungstenite::accept_async(stream).await.unwrap();
                let Some(Ok(Message::Binary(join))) = ws.next().await else {
                    panic!("missing first upstream subscription");
                };
                assert_eq!(protocol::join(&join).unwrap(), b"welcome-recover");
                if stalled {
                    // Hold a successfully upgraded connection without an ID.
                    // Only bridge retirement ends this read; no test-side timer
                    // or upstream Close triggers the expected frontend Close.
                    let _ = ws.next().await;
                }
                drop(ws);
                let (stream, _) = upstream.accept().await.unwrap();
                let mut ws = tokio_tungstenite::accept_async(stream).await.unwrap();
                assert!(matches!(ws.next().await, Some(Ok(Message::Binary(_)))));
                ws.send(Message::Binary(protocol::uint(42))).await.unwrap();
                assert!(matches!(ws.next().await, Some(Ok(Message::Close(_)))));
                assert!(transport::acknowledge_close(&mut ws, Duration::from_secs(1)).await);
            });
            let token = shutdown.clone();
            tasks.spawn(async move {
                serve(listener, upstream_url, 1, token).await.unwrap();
            });
            let (mut ws, _) = tokio_tungstenite::connect_async(&url).await.unwrap();
            ws.send(Message::Binary(Bytes::from_static(b"welcome-recover")))
                .await
                .unwrap();
            let began = tokio::time::Instant::now();
            let received = ws.next().await;
            let Some(Ok(Message::Close(Some(frame)))) = received else {
                panic!("welcome failure caused unclean legacy retirement: {received:?}");
            };
            assert_eq!(frame.code, CloseCode::Again);
            assert_eq!(frame.reason, "Upstream Unavailable");
            eprintln!(
                "welcome_failure stalled={stalled} elapsed={:?}",
                began.elapsed()
            );
            assert!(transport::acknowledge_close(&mut ws, Duration::from_secs(1)).await);
            assert!(ws.next().await.is_none());
            // A real welcome on the next connection proves the only admission
            // slot retired, without a bridge restart or retry state.
            let (mut recovered, _) = tokio_tungstenite::connect_async(&url).await.unwrap();
            recovered
                .send(Message::Binary(Bytes::from_static(b"welcome-recover")))
                .await
                .unwrap();
            assert_eq!(
                recovered.next().await.unwrap().unwrap(),
                Message::Binary(Bytes::copy_from_slice(&42u64.to_le_bytes()))
            );
            assert!(
                transport::initiate_close(&mut recovered, None, Duration::from_secs(1), None).await
            );
            shutdown.cancel();
            while let Some(result) = tasks.join_next().await {
                result.unwrap();
            }
        })
        .await
        .expect("welcome failure, clean Close and single-slot recovery must remain bounded");
    }

    #[tokio::test]
    async fn upstream_eof_before_welcome_closes_cleanly_and_recovers() {
        welcome_failure_closes_and_recovers(false).await;
    }

    #[tokio::test]
    async fn upstream_welcome_timeout_closes_cleanly_and_recovers() {
        welcome_failure_closes_and_recovers(true).await;
    }

    #[tokio::test]
    async fn unavailable_upstream_closes_cleanly_and_single_slot_recovers() {
        timeout(Duration::from_secs(2), async {
            // Reserve a port without listening: connection refusal is real,
            // and another test cannot claim the endpoint before recovery.
            let unavailable = socket2::Socket::new(
                socket2::Domain::IPV4,
                socket2::Type::STREAM,
                Some(socket2::Protocol::TCP),
            )
            .unwrap();
            unavailable
                .bind(
                    &"127.0.0.1:0"
                        .parse::<std::net::SocketAddr>()
                        .unwrap()
                        .into(),
                )
                .unwrap();
            let upstream_url = format!(
                "ws://{}",
                unavailable.local_addr().unwrap().as_socket().unwrap()
            );
            let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let url = format!("ws://{}", listener.local_addr().unwrap());
            let shutdown = CancellationToken::new();
            let token = shutdown.clone();
            let mut tasks = JoinSet::new();
            tasks.spawn(async move {
                serve(listener, upstream_url, 1, token).await.unwrap();
            });
            for _ in 0..2 {
                let (mut ws, _) = tokio_tungstenite::connect_async(&url).await.unwrap();
                ws.send(Message::Binary(Bytes::from_static(b"recover")))
                    .await
                    .unwrap();
                let received = ws.next().await;
                let Some(Ok(Message::Close(Some(frame)))) = received else {
                    panic!(
                        "upstream connection failure caused unclean legacy retirement: {received:?}"
                    );
                };
                assert_eq!(frame.code, CloseCode::Again);
                assert_eq!(frame.reason, "Upstream Unavailable");
                assert!(transport::acknowledge_close(&mut ws, Duration::from_secs(1)).await);
                assert!(ws.next().await.is_none());
            }
            // Bring the same endpoint online, with no bridge restart or retry state.
            unavailable.listen(16).unwrap();
            unavailable.set_nonblocking(true).unwrap();
            let upstream = TcpListener::from_std(unavailable.into()).unwrap();
            tasks.spawn(async move {
                let (stream, _) = upstream.accept().await.unwrap();
                let mut ws = tokio_tungstenite::accept_async(stream).await.unwrap();
                let Some(Ok(Message::Binary(join))) = ws.next().await else {
                    panic!("missing recovered join");
                };
                assert_eq!(protocol::join(&join).unwrap(), b"recover");
                ws.send(Message::Binary(protocol::uint(42))).await.unwrap();
                let expected = protocol::envelope(42, &protocol::byte_string(&[17, 34]));
                assert_eq!(
                    ws.next().await.unwrap().unwrap(),
                    Message::Binary(expected.clone())
                );
                ws.send(Message::Binary(expected)).await.unwrap();
                assert!(matches!(ws.next().await, Some(Ok(Message::Close(_)))));
                assert!(transport::acknowledge_close(&mut ws, Duration::from_secs(1)).await);
            });
            let (mut ws, _) = tokio_tungstenite::connect_async(&url).await.unwrap();
            ws.send(Message::Binary(Bytes::from_static(b"recover")))
                .await
                .unwrap();
            assert_eq!(
                ws.next().await.unwrap().unwrap(),
                Message::Binary(Bytes::copy_from_slice(&42u64.to_le_bytes()))
            );
            let mut packet = 42u64.to_le_bytes().to_vec();
            packet.extend_from_slice(&[17, 34]);
            ws.send(Message::Binary(packet.clone().into()))
                .await
                .unwrap();
            assert_eq!(
                ws.next().await.unwrap().unwrap(),
                Message::Binary(packet.into())
            );
            assert!(transport::initiate_close(&mut ws, None, Duration::from_secs(1), None).await);
            assert!(ws.next().await.is_none());
            shutdown.cancel();
            while let Some(result) = tasks.join_next().await {
                result.unwrap();
            }
        })
        .await
        .expect("two refused upstream connections and recovery must be prompt");
    }

    async fn welcome_validation_cases(cases: Vec<(Message, Option<u64>)>) {
        timeout(Duration::from_secs(2), async {
            let upstream = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let upstream_url = format!("ws://{}", upstream.local_addr().unwrap());
            let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let url = format!("ws://{}", listener.local_addr().unwrap());
            let shutdown = CancellationToken::new();
            let mut tasks = JoinSet::new();
            let expected_cases = cases.clone();
            tasks.spawn(async move {
                for (message, id) in expected_cases {
                    let (stream, _) = upstream.accept().await.unwrap();
                    let mut ws = tokio_tungstenite::accept_async(stream).await.unwrap();
                    assert!(matches!(ws.next().await, Some(Ok(Message::Binary(_)))));
                    ws.send(message).await.unwrap();
                    let Some(Ok(Message::Close(Some(frame)))) = ws.next().await else {
                        panic!("upstream did not receive clean Close");
                    };
                    assert_eq!(
                        frame.code,
                        if id.is_some() {
                            CloseCode::Normal
                        } else {
                            CloseCode::Protocol
                        }
                    );
                    assert_eq!(
                        frame.reason,
                        if id.is_some() {
                            "done"
                        } else {
                            "Invalid Upstream Welcome"
                        }
                    );
                    assert!(transport::acknowledge_close(&mut ws, Duration::from_secs(1)).await);
                    assert!(ws.next().await.is_none());
                }
            });
            let token = shutdown.clone();
            tasks.spawn(async move {
                serve(listener, upstream_url, 1, token).await.unwrap();
            });
            for (_, id) in cases {
                let (mut ws, _) = tokio_tungstenite::connect_async(&url).await.unwrap();
                ws.send(Message::Binary(Bytes::from_static(b"validation")))
                    .await
                    .unwrap();
                if let Some(id) = id {
                    assert_eq!(
                        ws.next().await.unwrap().unwrap(),
                        Message::Binary(Bytes::copy_from_slice(&id.to_le_bytes()))
                    );
                    assert!(
                        transport::initiate_close(
                            &mut ws,
                            Some(CloseFrame {
                                code: CloseCode::Normal,
                                reason: "done".into()
                            }),
                            Duration::from_secs(1),
                            None
                        )
                        .await
                    );
                    assert!(ws.next().await.is_none());
                } else {
                    let received = ws.next().await;
                    let Some(Ok(Message::Close(Some(frame)))) = received else {
                        panic!("invalid welcome was exposed as a legacy ID: {received:?}");
                    };
                    assert_eq!(frame.code, CloseCode::Protocol);
                    assert_eq!(frame.reason, "Invalid Upstream Welcome");
                    assert!(transport::acknowledge_close(&mut ws, Duration::from_secs(1)).await);
                    assert!(ws.next().await.is_none());
                }
            }
            shutdown.cancel();
            while let Some(result) = tasks.join_next().await {
                result.unwrap();
            }
        })
        .await
        .expect("welcome validation and one-slot reuse must be prompt");
    }

    #[tokio::test]
    async fn invalid_upstream_welcome_ids_and_trailing_values_close_both_peers() {
        let cases = vec![
            protocol::uint(0),
            Bytes::new(),
            protocol::uint(u64::MAX),
            Bytes::from_static(&[0x18]),
            Bytes::from_static(&[0x20]),
            Bytes::from_static(&[0x61, b'x']),
            Bytes::from_static(&[0xf6]),
            Bytes::from_static(&[0x82, 1, 2]),
            Bytes::from_static(&[0x18, 42, 0]),
        ];
        let mut cases: Vec<_> = cases
            .into_iter()
            .map(|bytes| (Message::Binary(bytes), None))
            .collect();
        cases.push((Message::Text("42".into()), None));
        welcome_validation_cases(cases).await;
    }

    #[tokio::test]
    async fn complete_uint64_welcomes_keep_all_widths_and_noncanonical_encoding() {
        let mut cases: Vec<_> = [
            1,
            23,
            24,
            255,
            256,
            65535,
            65536,
            u32::MAX as u64,
            u64::MAX - 1,
        ]
        .into_iter()
        .map(|id| (Message::Binary(protocol::uint(id)), Some(id)))
        .collect();
        cases.push((
            Message::Binary(Bytes::from_static(&[0x1b, 0, 0, 0, 0, 0, 0, 0, 42])),
            Some(42),
        ));
        welcome_validation_cases(cases).await;
    }

    #[tokio::test]
    async fn invalid_frames_send_policy_close_before_and_after_join() {
        use tokio::io::AsyncWriteExt;
        timeout(Duration::from_secs(2), async {
            for (joined, kind) in [false, true]
                .into_iter()
                .flat_map(|joined| (0..5).map(move |kind| (joined, kind)))
            {
                let upstream = TcpListener::bind("127.0.0.1:0").await.unwrap();
                let upstream_url = format!("ws://{}", upstream.local_addr().unwrap());
                let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
                let url = format!("ws://{}", listener.local_addr().unwrap());
                let shutdown = CancellationToken::new();
                let mut tasks = JoinSet::new();
                tasks.spawn(async move {
                    let (stream, _) = upstream.accept().await.unwrap();
                    let mut ws = tokio_tungstenite::accept_async(stream).await.unwrap();
                    assert!(matches!(ws.next().await, Some(Ok(Message::Binary(_)))));
                    ws.send(Message::Binary(protocol::uint(1))).await.unwrap();
                    while ws.next().await.is_some_and(|message| message.is_ok()) {}
                });
                let token = shutdown.clone();
                tasks.spawn(async move {
                    serve(listener, upstream_url, 1, token).await.unwrap();
                });
                let (mut ws, _) = tokio_tungstenite::connect_async(url).await.unwrap();
                if joined {
                    ws.send(Message::Binary(Bytes::from_static(b"size-check")))
                        .await
                        .unwrap();
                    assert!(matches!(ws.next().await, Some(Ok(Message::Binary(_)))));
                }
                // No large payload allocation: rejection follows the advertised length.
                let mut header = [0; 14];
                header[..2].copy_from_slice(&[0x82, 0xff]);
                header[2..10].copy_from_slice(&(16 * 1024 * 1024 + 1u64).to_be_bytes());
                let (wire, code, reason) = match kind {
                    0 => (&header[..], CloseCode::Size, "Message Too Large"),
                    1 => (&[0x82, 1, 42][..], CloseCode::Protocol, "Protocol Error"),
                    2 => (
                        &[0x83, 0x80, 0, 0, 0, 0][..],
                        CloseCode::Protocol,
                        "Protocol Error",
                    ),
                    3 => (
                        &[0x09, 0x80, 0, 0, 0, 0][..],
                        CloseCode::Protocol,
                        "Protocol Error",
                    ),
                    _ => (
                        &[0x81, 0x81, 0, 0, 0, 0, 0xff][..],
                        CloseCode::Invalid,
                        "Invalid UTF-8",
                    ),
                };
                ws.get_mut().write_all(wire).await.unwrap();
                let Some(Ok(Message::Close(Some(frame)))) = ws.next().await else {
                    panic!("invalid frame did not receive Close: joined={joined}, kind={kind}");
                };
                assert_eq!(frame.code, code);
                assert_eq!(frame.reason, reason);
                shutdown.cancel();
                tasks.shutdown().await;
            }
        })
        .await
        .expect("invalid-frame rejection must be prompt");
    }

    #[tokio::test]
    async fn invalid_upstream_is_rejected_before_the_accept_loop() {
        for upstream in ["not a URL", "http://localhost/", "ws://", "/relative"] {
            let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let shutdown = CancellationToken::new();
            shutdown.cancel();
            let result = serve_with_limits(
                listener,
                upstream.into(),
                1,
                0,
                crate::origin::OriginPolicy::default(),
                shutdown,
            )
            .await;
            assert!(result.is_err(), "invalid upstream accepted: {upstream}");
        }
    }

    #[test]
    fn upstream_validation_accepts_websocket_urls_without_connecting() {
        for upstream in [
            "ws://127.0.0.1:1338",
            "ws://[::1]:1338/path?mode=cbor",
            "wss://relay.example.invalid:443/path",
        ] {
            validate_upstream(upstream).unwrap();
        }
    }

    #[test]
    fn scalar_commands_preserve_flags_and_all_id_widths() {
        for flags in [0, 7, 23, 24, 255] {
            let mut packet = vec![0; 8];
            packet.extend_from_slice(&[1, flags]);
            assert_eq!(
                to_cbor(Message::Binary(packet.into())).unwrap().unwrap(),
                protocol::request(1, &protocol::uint(u64::from(flags)))
            );
        }
        for id in [
            0,
            1,
            23,
            24,
            255,
            256,
            65535,
            65536,
            u32::MAX as u64,
            u32::MAX as u64 + 1,
            u64::MAX,
        ] {
            let mut packet = vec![0; 8];
            packet.push(3);
            packet.extend_from_slice(&id.to_le_bytes());
            assert_eq!(
                to_cbor(Message::Binary(packet.into())).unwrap().unwrap(),
                protocol::request(3, &protocol::uint(id))
            );
        }
    }

    #[test]
    fn byte_commands_preserve_length_boundaries_and_empty_key_behavior() {
        for op in [0, 5] {
            for length in [0, 1, 23, 24, 255, 256, 4096] {
                if op == 5 && length > 255 {
                    continue;
                }
                let value = vec![b'a'; length];
                let mut input = vec![0; 8];
                input.push(op);
                input.extend_from_slice(&value);
                let actual = to_cbor(Message::Binary(input.into())).unwrap();
                if op == 5 && length == 0 {
                    assert_eq!(actual, None);
                } else {
                    assert_eq!(
                        actual.unwrap(),
                        protocol::request(op, &protocol::byte_string(&value))
                    );
                }
            }
        }
    }

    #[test]
    fn variable_writes_preserve_key_and_value_length_boundaries() {
        for key_len in [1, 23, 24, 255] {
            let key = vec![b'k'; key_len];
            for value_len in [0, 23, 24, 255, 256, 65535, 65536] {
                let value = vec![0xa5; value_len];
                let mut input = vec![0; 8];
                input.extend_from_slice(&[4, key_len as u8]);
                input.extend_from_slice(&key);
                input.extend_from_slice(&value);
                let mut pair = vec![0x82];
                pair.extend_from_slice(&protocol::byte_string(&key));
                pair.extend_from_slice(&protocol::byte_string(&value));
                assert_eq!(
                    to_cbor(Message::Binary(input.into())).unwrap().unwrap(),
                    protocol::request(4, &pair)
                );
            }
        }
    }

    #[test]
    fn binary_envelopes_keep_canonical_headers_and_exact_owned_storage() {
        let targets: &[(u64, &[u8])] = &[
            (1, b"\x01"),
            (23, b"\x17"),
            (24, b"\x18\x18"),
            (255, b"\x18\xff"),
            (256, b"\x19\x01\x00"),
            (65535, b"\x19\xff\xff"),
            (65536, b"\x1a\x00\x01\x00\x00"),
            (u32::MAX as u64, b"\x1a\xff\xff\xff\xff"),
            (u32::MAX as u64 + 1, b"\x1b\x00\x00\x00\x01\x00\x00\x00\x00"),
            (u64::MAX, b"\x1b\xff\xff\xff\xff\xff\xff\xff\xff"),
        ];
        let lengths: &[(usize, &[u8])] = &[
            (1, b"\x41"),
            (23, b"\x57"),
            (24, b"\x58\x18"),
            (255, b"\x58\xff"),
            (256, b"\x59\x01\x00"),
            (65535, b"\x59\xff\xff"),
            (65536, b"\x5a\x00\x01\x00\x00"),
        ];
        for &(target, encoded_target) in targets {
            for &(len, encoded_length) in lengths {
                let payload: Vec<_> = (0..len).map(|i| i as u8).collect();
                let mut input = target.to_le_bytes().to_vec();
                input.extend_from_slice(&payload);
                let input = Bytes::from(input);
                let result = to_cbor(Message::Binary(input.clone())).unwrap().unwrap();
                let mut expected = vec![0x82];
                expected.extend_from_slice(encoded_target);
                expected.extend_from_slice(encoded_length);
                expected.extend_from_slice(&payload);
                assert_eq!(result.as_ref(), expected);
                assert_eq!(&input[8..], payload);
                let owned = result.try_into_mut().expect("independently owned envelope");
                assert_eq!(owned.capacity(), owned.len());
            }
        }
        assert_eq!(
            to_cbor(Message::Binary(Bytes::copy_from_slice(&1u64.to_le_bytes()))),
            Err(Disconnect::PROTOCOL),
        );
    }

    #[test]
    fn text_envelopes_preserve_utf8_byte_lengths_and_exact_owned_storage() {
        let targets: &[(u64, &[u8])] = &[
            (1, b"\x01"),
            (256, b"\x19\x01\x00"),
            (u64::MAX, b"\x1b\xff\xff\xff\xff\xff\xff\xff\xff"),
        ];
        let lengths: &[(usize, &[u8])] = &[
            (1, b"\x61"),
            (23, b"\x77"),
            (24, b"\x78\x18"),
            (255, b"\x78\xff"),
            (256, b"\x79\x01\x00"),
            (65535, b"\x79\xff\xff"),
            (65536, b"\x7a\x00\x01\x00\x00"),
        ];
        for &(target, encoded_target) in targets {
            for &(len, encoded_length) in lengths {
                let payload = "λ".repeat(len / 2) + if len % 2 == 1 { "x" } else { "" };
                assert_eq!(payload.len(), len);
                let input: tokio_tungstenite::tungstenite::Utf8Bytes =
                    (STANDARD.encode(target.to_le_bytes()) + &payload).into();
                let result = to_cbor(Message::Text(input.clone())).unwrap().unwrap();
                let mut expected = vec![0x82];
                expected.extend_from_slice(encoded_target);
                expected.extend_from_slice(encoded_length);
                expected.extend_from_slice(payload.as_bytes());
                assert_eq!(result.as_ref(), expected);
                assert_eq!(&input[12..], payload);
                let owned = result.try_into_mut().expect("independently owned envelope");
                assert_eq!(owned.capacity(), owned.len());
            }
        }
        let input = STANDARD.encode(1u64.to_le_bytes()) + "\0λ🦀e\u{301}";
        assert_eq!(
            to_cbor(Message::Text(input.into()))
                .unwrap()
                .unwrap()
                .as_ref(),
            b"\x82\x01\x6a\x00\xce\xbb\xf0\x9f\xa6\x80e\xcc\x81",
        );
        let empty = STANDARD.encode(1u64.to_le_bytes());
        assert_eq!(
            to_cbor(Message::Text(empty.into())),
            Err(Disconnect::PROTOCOL)
        );
        assert_eq!(
            to_cbor(Message::Text("!!!!!!!!!!!!x".into())),
            Err(Disconnect::PROTOCOL)
        );
        let ignored = STANDARD.encode(0u64.to_le_bytes()) + "λ";
        assert_eq!(to_cbor(Message::Text(ignored.into())).unwrap(), None);
    }
}
