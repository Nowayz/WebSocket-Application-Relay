import subprocess
for index, variant in enumerate(['control', 'candidate', 'candidate', 'control']):
    sidecar = 'artifacts/candidates/window-timeout-control/inspection' if variant == 'control' else 'artifacts/candidates/window-timeout/inspection'
    command = ['python', 'scripts/mixed-capacity.py', '--server', 'artifacts/candidates/queue-initial-control/war-relay', '--sidecar', sidecar, '--capacity-client', 'artifacts/candidates/latency-timeline-client/capacity', '--users', '100000', '--seconds', '2', '--readers', '8192', '--scope', 'room', '--window', '4', '--inspectors', '0', '--pairs', '0', '--churn-workers', '0', '--fanout-windows-per-second', '16', '--exact-fanout-latency', '--pin-client-workers', '--output', f'artifacts/window-timeout-light-{index}-{variant}.json']
    print('starting', index, variant, flush=True)
    with open(f'artifacts/window-timeout-light-{index}-{variant}.log', 'x') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=180)
    print('finished', index, variant, result.returncode, flush=True)
    assert result.returncode in [0, 1]
