import subprocess
for index,kind in enumerate(['control','candidate','candidate','control']):
 client='fanout-send-first-control' if kind=='control' else 'fanout-send-first-fixed'
 source='fanout-send-first-control-work' if kind=='control' else 'fanout-send-first-candidate-work'
 command=['python','scripts/inspection.py','--server','artifacts/candidates/queue-initial-control/war-relay','--client',f'artifacts/candidates/{client}/inspection','--client-source-root',f'artifacts/{source}','--mode','none','--rooms','0','--seconds','2','--inspectors','0','--pairs','64','--churn-workers','0','--client-workers','8','--workers','4','--fanout-readers','2048','--fanout-window','4','--fanout-close-window','32','--pin-workers','--pin-client-workers','--server-cpus','0-3','--client-cpus','4-7,20-23','--output',f'artifacts/fanout-send-first-{index}-{kind}.json']
 with open(f'artifacts/fanout-send-first-{index}-{kind}.log','w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=60)
 print(index,kind,flush=True)
