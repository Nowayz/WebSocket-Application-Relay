import argparse,hashlib,http.client,importlib.util,json,os,socket,subprocess,time
from pathlib import Path
from http.client import HTTPConnection
root=Path.cwd();spec=importlib.util.spec_from_file_location('corpus',root/'scripts/input-corpus.py');corpus=importlib.util.module_from_spec(spec);spec.loader.exec_module(corpus)
parser=argparse.ArgumentParser();parser.add_argument('--server',required=True);parser.add_argument('--variant',choices=['control','selected'],required=True);args=parser.parse_args()
def port():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
data,admin=port(),port()
while admin==data:admin=port()
def http(method,path,token=None):
 conn=HTTPConnection('127.0.0.1',admin,timeout=3)
 headers={'Connection':'close','Content-Length':'0'}
 if token is not None:headers['Authorization']='Bearer '+token
 try:
  conn.request(method,path,headers=headers);response=conn.getresponse();return response.status,response.read().decode()
 finally:conn.close()
def metrics():
 status,body=http('GET','/metrics','admin-path-test');assert status==200
 return {k:int(v) for k,v in (line.split() for line in body.splitlines() if line.startswith('war_'))}
def transfer(source,target):
 source.socket.sendall(corpus.wire.frame(0x82,b'\x82\x1b'+target.id.to_bytes(8,'big')+b'\x18\x2a'))
 opcode,body=target.receive();assert opcode==2 and body[0]==0x82
 sender,end=corpus.wire.uint(body,1);assert sender==source.id and body[end:]==b'\x18\x2a'
server=Path(args.server).resolve();command=[str(server),'--bind',f'127.0.0.1:{data}','--admin-bind',f'127.0.0.1:{admin}','--workers','2','--ping-interval-secs','0']
env={k:v for k,v in os.environ.items() if not k.startswith('WAR_')};env['WAR_ADMIN_TOKEN']='admin-path-test'
record={'passed':False,'variant':args.variant,'command':command,'server_sha256':hashlib.sha256(server.read_bytes()).hexdigest(),'requests':[]};peers=[]
with open(root/f'artifacts/admin-path-live-v3-{args.variant}-server.log','x') as log:
 process=subprocess.Popen(command,env=env,stdout=log,stderr=log)
 try:
  deadline=time.monotonic()+5
  while True:
   assert process.poll() is None
   try:
    assert http('GET','/readyz')[0]==200;break
   except OSError:
    assert time.monotonic()<deadline;time.sleep(.01)
  for _ in range(2):
   peer=corpus.Peer(data);peer.join(b'admin-path');peers.append(peer)
  verified=0
  for identity in ['bad','-1','18446744073709551616','%FF','0','18446744073709551615',str(peers[0].id)]:
   for token in [None,'wrong-token','admin-path-test']:
    if token=='admin-path-test' and identity==str(peers[0].id):continue
    malformed=identity in ['bad','-1','18446744073709551616','%FF']
    expected=(400 if malformed else 404) if token=='admin-path-test' else (400 if malformed and args.variant=='control' else 401)
    status,body=http('POST',f'/v1/sessions/{identity}/disconnect',token)
    record['requests'].append({'id':identity,'credentials':'valid' if token=='admin-path-test' else ('wrong' if token else 'missing'),'status':status,'body':body});assert status==expected
    transfer(*peers);verified+=1
  assert metrics()['war_sessions']==2
  assert http('POST',f'/v1/sessions/{peers[0].id}/disconnect','admin-path-test')[0]==204
  peers[0].policy_close(4000)
  opcode,body=peers[1].receive();assert opcode==2 and body[0]==0x82
  sender,end=corpus.wire.uint(body,1);departed,end=corpus.wire.uint(body,end)
  assert sender==2**64-1 and departed==peers[0].id and end==len(body)
  peers[1].socket.sendall(corpus.wire.frame(0x88,(1000).to_bytes(2,'big')))
  opcode,body=peers[1].receive();assert opcode==8 and body==(1000).to_bytes(2,'big');assert peers[1].socket.recv(1)==b''
  deadline=time.monotonic()+3
  while True:
   final=metrics()
   if all(final[k]==0 for k in ['war_connections','war_sessions','war_queued_bytes','war_read_buffer_reserved_bytes','war_output_queue_capacity_bytes']):break
   assert time.monotonic()<deadline;time.sleep(.01)
  assert final['war_routing_copied_bytes_total']==final['war_protocol_errors_total']==0
  process.terminate();assert process.wait(timeout=5)==0
  record.update(passed=True,healthy_verified=verified,administrative_close=4000,departure_verified=True,final_metrics=final,exit_code=process.returncode)
 finally:
  for peer in peers:peer.socket.close()
  if process.poll() is None:process.kill();process.wait(timeout=5)
  (root/f'artifacts/admin-path-live-v3-{args.variant}.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'variant':args.variant,'passed':record['passed'],'healthy_verified':record.get('healthy_verified')}))
