import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import test from 'node:test';
const source = await readFile(new URL('../target/browser/relay.js', import.meta.url));
const moduleUrl = `data:text/javascript;base64,${source.toString('base64')}`;
const nodeBuffer = globalThis.Buffer;
globalThis.Buffer = undefined; // Select the codec's browser Uint8Array allocation path.
let Relay;
try { ({ Relay } = await import(moduleUrl)); }
finally { globalThis.Buffer = nodeBuffer; }

test('built browser module captures a reused byte channel against native relay', async t => {
  const expected = new Uint8Array([0, 255, 66, 85, 78, 68, 76, 69]);
  const channel = expected.slice();
  const pending = Relay.connect(process.env.WAR_TEST_URL, channel);
  channel.fill(120);
  const relay = await pending;
  t.after(() => relay.close());
  assert.equal(await relay.authenticate('js-test-host'), true);
  const rows = await relay.channels();
  const found = rows.find(([name]) => name.length === expected.length && name.every((v, i) => v === expected[i]));
  assert.ok(found);
  assert.equal(found[1], 1);
});
