import hashlib,importlib.util,json,os,socket,subprocess,time,urllib.request
from pathlib import Path
root=Path.cwd()
spec=importlib.util.spec_from_file_location('corpus',root/'scripts/input-corpus.py');corpus=importlib.util.module_from_spec(spec);spec.loader.exec_module(corpus)
def free_port():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
port,admin=free_port(),free_port()
while admin==port:admin=free_port()
server=root/'artifacts/candidates/shutdown-drain/war-relay'
command=[str(server),'--bind',f'127.0.0.1:{port}','--admin-bind',f'127.0.0.1:{admin}','--workers','2','--shutdown-timeout-secs','1','--ping-interval-secs','0']
env={k:v for k,v in os.environ.items() if not k.startswith('WAR_')}
record={'passed':False,'command':command,'server_sha256':hashlib.sha256(server.read_bytes()).hexdigest()};peers=[];half=None
with open(root/'artifacts/shutdown-drain-smoke-server.log','x') as log:
 process=subprocess.Popen(command,env=env,stdout=log,stderr=log)
 try:
  deadline=time.monotonic()+5
  while True:
   assert process.poll() is None
   try:
    with urllib.request.urlopen(f'http://127.0.0.1:{admin}/readyz',timeout=.2) as response:assert response.status==200
    break
   except OSError:
    assert time.monotonic()<deadline
    time.sleep(.01)
  for _ in range(4):
   peer=corpus.Peer(port);peer.join(b'shutdown');peers.append(peer)
  assert len({p.id for p in peers})==4
  half=socket.create_connection(('127.0.0.1',port),timeout=3);half.sendall(b'GET / HTTP/1.1\r\nHost:')
  start=time.monotonic();process.terminate()
  closes=[]
  for i,peer in enumerate(peers):
   opcode,body=peer.receive();assert opcode==8 and int.from_bytes(body[:2],'big')==1001
   closes.append({'id':peer.id,'code':1001,'acknowledged':i<3})
   if i<3:peer.socket.sendall(corpus.wire.frame(0x88,body))
  assert process.wait(timeout=4)==0
  elapsed=time.monotonic()-start
  for peer in peers:assert peer.socket.recv(1)==b''
  assert half.recv(1)==b''
  record.update(passed=True,closes=closes,joined_peers=4,unacknowledged_peers=1,incomplete_upgrades=1,transport_eofs=5,shutdown_seconds=elapsed,exit_code=process.returncode)
 finally:
  for peer in peers:peer.socket.close()
  if half is not None:half.close()
  if process.poll() is None:process.kill();process.wait(timeout=5)
  (root/'artifacts/shutdown-drain-smoke.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
